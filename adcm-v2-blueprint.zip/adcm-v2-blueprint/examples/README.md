# Jak używać przykładów

Wszystkie dane są demonstracyjne. `.invalid` to celowo niedziałająca domena. Nazwy tools są fixture, nie rzeczywiste API Atlassian. `demo-contract.json` pasuje do stuba, nie do nieznanego schematu produkcyjnego. `scenarios.json` to dane do budowy testów, nie gotowy runner.

`turn-result.json` przedstawia wynik odrzucenia niepoprawnej godziny i odpowiedzi o polach. `tool_trace=[]` jest skrótem przykładu, a nie oczekiwaniem dla rzeczywistej tury narzędziowej. `extraction-mapping.json` pokazuje osobny plik mapping wskazywany w rozszerzeniu konfiguracji S15; nie dodawaj nieznanych kluczy env do parsera S11 bez jawnego rozszerzenia jego schema.
