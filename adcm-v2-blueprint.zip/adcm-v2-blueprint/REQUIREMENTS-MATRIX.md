# Pokrycie wymagań

| ID | Wymaganie | Etapy | Dowód odbioru |
|---|---|---|---|
| R01 | Jeden serwis, hexagonal, Forge internal plugin | S01,S05,S27 | Import boundaries; Forge bez HTTP/MCP/SDK |
| R02 | CLI, biblioteka i worker bez WWW | S09,S25 | Ten sam TurnService i wynik |
| R03 | Chat informacyjny i wiele celów w turze | S07,S14 | E01,E03,E07 |
| R04 | Jira/Confluence i łańcuch MCP | S12,S14 | E04,E05,E13 |
| R05 | Dynamiczne MCP wyłącznie konfiguracją | S11,S12 | Trzeci fixture MCP bez zmiany kodu |
| R06 | Pełny audyt pola, źródło, tura, powód | S04,S16,S19 | E02,E15,E19 |
| R07 | Historia Pydantic AI i deps per tura | S05,S08,S10 | Round-trip i izolacja |
| R08 | Structured output i semantic blocks | S01,S18,S33 | Referencje i renderery |
| R09 | Kopiowanie istniejącego pipeline | S15 | E06,E22 |
| R10 | Usunięcie/podmiana kolumn i pliki | S16,S17 | E06,E15,E23 |
| R11 | Forge off = asystent wiedzy | S05,S08,S14 | E04,E20 |
| R12 | Limity i poprawna obsługa błędu walidacji | S06,S08 | E03,E14 |
| R13 | Źródła i oznaczenia ostatniej tury w YAML | S19,S33 | YAML semantic equality |
| R14 | Sesje i ustawienia zapamiętane w browser | S20,S34 | Reload i fork nieufnego snapshot |
| R15 | Osobne tokeny Jira/Confluence i write switch | S13,S24,S34 | E12,E17,E24 |
| R16 | GCP JSON logs, app/session, tool tracing | S21,S22 | JSON lines i fake exporter |
| R17 | Trzy poziomy testowania | S00,S23 | Offline vs live raport |
| R18 | Pełny Forge dopiero na końcu backendu | S28–S32 | Production fixtures i parity |
| R19 | Web ostatni, wszystkie funkcje wcześniej | S26,S33–S35 | Headless suite nadal PASS |
| R20 | Zależne pola bez zgadywania ścieżek | S03,S30 | E08,E09 |
| R21 | Odporność retry/concurrency/storage | S02,S06,S10 | E10,E11,E18 |
| R22 | Enrichment precedence i deterministyczne reguły | S28,S31 | Audit causal i cycle rollback |

## Świadome ograniczenia

Obsługa wiedzy odbywa się przez istniejące MCP; nie budujemy indeksu Confluence ani katalogu pipeline'ów w ADCM. Nie mamy dostępu do rzeczywistych endpointów i schematu produkcyjnego, więc zgodność z nimi wymaga późniejszego testu. Attachment MVP: tekst, CSV, TSV, JSON. Pełne integracje plikowe/OCR, duża baza produkcyjna GCP, enterprise auth, broker i cross-device sync są osobnymi rozszerzeniami. Te ograniczenia nie blokują testowania całego przepływu na stubie i fixture MCP.
