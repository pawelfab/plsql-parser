# Handoff SNN — nazwa

- Status: PASS | BLOCKED | FAILED | NOT_STARTED | SKIPPED_OPTIONAL
- Commit / stan repo:
- Zależności i ich status:
- Cel zrealizowany (maks. 5 zdań):
- Zmienione pliki:
- Publiczne symbole i sygnatury:
- Czy zmieniono kontrakt specyfikacji? Nie / propozycja + decyzja:
- Komendy testów i rzeczywiste wyniki:
- Testy NOT_RUN i powód:
- Znane ograniczenia:
- Sekrety/dane testowe: wyłącznie fixture, bez rzeczywistych tokenów:
- Następny stage i minimalne pliki do odczytu:
- Jeśli BLOCKED: brakujący zasób, właściciel decyzji, najmniejszy krok odblokowania:
