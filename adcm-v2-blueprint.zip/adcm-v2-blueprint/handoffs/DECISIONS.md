# Rejestr późniejszych decyzji

Początkowy stan: brak zmian wobec specyfikacji 1.0.
Dopisuj: data, stage, problem, decyzja właściciela, zmienione kontrakty, dotknięte etapy i testy. Nie zastępuj treści wcześniejszych decyzji. Zgodność z nowym API SDK, która nie zmienia publicznego portu, wymaga wpisu compatibility.md, nie przebudowy architektury.
