# Stabilne kontrakty v1

To specyfikacja typów, nie kompletny kod. Wszystkie daty timezone-aware UTC ISO 8601. UUID to string, JSON to wyłącznie wartości zgodne z JSON. Wszystkie kolekcje mają default_factory. DTO publiczne mają `extra=forbid`, wersję i jawne discriminator `type` dla unii bloków.

## Sesja i tura
- `SessionSnapshot`: schema_version=1, session_id, owner_id, revision:int>=0, turn_index:int>=0, plugin_states:dict[str,JSON], history_branches, active_history_id, turns:list[TurnRecord], settings:SessionSettings.
- `SessionSettings`: external_writes_enabled=false, timezone="UTC", forge_enabled:bool, selected_mcp_ids:list[str]. Efektywna flaga Forge to konfiguracja globalna AND ustawienie sesji. Brak ustawienia sesji dziedziczy globalne. Ustawienia zmienia osobna komenda, nie LLM.
- `TurnRequest`: request_id, session_id, expected_revision, prompt, attachment_ids=[], input_schema_version=1. Puste prompt dopuszczalne tylko z załącznikiem i poleceniem opisanym przez API klienta; sam plik bez celu prowadzi do pytania doprecyzowującego, nie mutacji.
- `TurnContext`: session_id, actor_id (z auth), request_id, turn_id, turn_index, started_at, base_revision, cancellation, budgets; wartości te ustala aplikacja.
- `TurnRecord`: turn_id, request_id, turn_index, status, response, change_ids, attempts, tool_traces, started_at, finished_at. `status`: completed | partial | failed. Odrzucona mutacja i udzielona odpowiedź → partial; zwykłe pytanie → completed.
- `TurnResult`: schema_version=1, session_id, revision, turn_index, status, response:TurnResponse, diff:list[FieldChange], contract:JSON|null, diagnostics:list[Diagnostic], tool_trace:list[ToolTrace], replayed:bool.
- `TurnResponse`: blocks:list[Block], questions:list[str]. LLM generuje tę część; nie generuje revision, diff ani contract. Aplikacja dokłada deterministyczny blok wyników operacji na podstawie attempts, co uniemożliwia ukrycie odrzucenia w samym tekście.

## Bloki odpowiedzi
`TextBlock(type=text, markdown)`; `EntityListBlock(type=entities, items:[EntityRef])`; `FieldListBlock(type=fields, items:[FieldRef])`; `SourceListBlock(type=sources, source_ids)`; `NoticeBlock(type=notice, level, code, text)`. EntityRef ma kind, id, label, source_id; FieldRef ma path, label, availability i schema_revision. Brak arbitralnego HTML, executable UI i dowolnych URL. URL wyświetlany tylko z zarejestrowanego SourceRef (http/https). Referencje LLM są weryfikowane z rejestrem tury/sesji, nie akceptowane na wiarę. Brak Forge → FieldListBlock niedostępny lub odrzucony przez validator. Finalny kontrakt bloków jest wspólny dla CLI i WWW.

## Forge
`ForgeState`: schema_id, schema_version, doc:dict, audit:list[FieldChange], entity_ids:dict. Canonical path to JSON Pointer RFC 6901, np. `/silver/tables/0/columns`, nie notacja kropkowa. Escaping ~0 i ~1. Root replacement wyłącznie przez import_contract; update nie przyjmuje pustej ścieżki ani `-` append.
`ValueSlot`: exists:bool, value:JSON (null, gdy exists=false). Brak i null to różne przypadki.
`SourceRef`: source_id, kind (user_text|attachment|mcp|pipeline|system_rule|default), locator, version, content_hash, evidence (opcjonalny krótki fragment); bez tokenów.
`FieldChange`: change_id, operation_id, turn_id, turn_index, sequence, path, entity_id|null, action (add|replace|remove), old:ValueSlot, new:ValueSlot, actor_id, executor="forge", source_id, reason, reason_kind (user_instruction|derived_rule|import|default), rule_id|null, caused_by_change_id|null, timestamp. Powód LLM oznacz jako opis modelu, nie dosłowną wypowiedź użytkownika. Faktyczne pochodzenie ustala kod ze wskazanego i zweryfikowanego SourceRef.
`MutationCommand`: operation_id, expected_working_revision, operations:[SetOp|RemoveOp], reason, source_id. SetOp ma op=set,path,value; RemoveOp ma op=remove,path. Jeden command jest atomowy. Kolekcje zastępuj osobną operacją replace_collection(path,items,source_id), bez set dowolnego rodzica. Limit 200 operacji i 1 MiB dokumentu w stubie; konfigurowalny.
`MutationResult`: status=applied|noop|rejected, operation_id, working_revision, changes, diagnostics. `Diagnostic`: code, path|null, message, severity, details. Błędy: UNKNOWN_PATH, TYPE_MISMATCH, INVALID_VALUE, CONDITION_UNMET, REVISION_CONFLICT, SOURCE_UNKNOWN, OPERATION_REUSE_MISMATCH. Wyjątek infrastruktury nie jest rejected.
`ValidationReport`: valid:bool, complete:bool, diagnostics, missing_paths, schema_revision, scope (demo|production). valid oznacza brak nieprawidłowych obecnych wartości; complete brak wymaganych braków. Jawne validate nie uruchamia enrichment.
`SectionInfo`: id,label,description. `FieldSchemaInfo`: path,type,description,examples,allowed_values,required,availability (available|conditional|unavailable),conditions,read_only,schema_revision. Odkrywanie zależy od bieżącego dokumentu, nie od samej nazwy sekcji.

## Sygnatury portów
```python
class ForgeEngine(Protocol):
    def list_sections(self) -> list[SectionInfo]: ...
    def get_section_fields(self, section: str) -> list[FieldSchemaInfo]: ...
    def inspect(self, path: str) -> ValueSlot: ...
    def apply(self, command: MutationCommand) -> MutationResult: ...
    def replace_collection(self, command: CollectionCommand) -> MutationResult: ...
    def import_contract(self, command: ImportCommand) -> MutationResult: ...
    def validate(self) -> ValidationReport: ...
    def inspect_provenance(self, path: str, cursor: str | None, limit: int) -> AuditPage: ...
    def snapshot(self) -> ForgeState: ...

class SessionRepository(Protocol):
    async def create(self, snapshot: SessionSnapshot) -> None: ...
    async def load(self, owner_id: str, session_id: str) -> SessionSnapshot: ...
    async def commit(self, snapshot: SessionSnapshot, expected_revision: int,
                     request_id: str, result: TurnResult) -> None: ...
    async def find_result(self, owner_id: str, session_id: str,
                          request_id: str) -> StoredRequest | None: ...

class AgentRunnerPort(Protocol):
    async def run(self, prompt, history, deps, tool_catalog, limits) -> AgentOutcome: ...

class ExternalToolsPort(Protocol):
    async def catalog(self, runtime_context) -> list[ExternalToolSpec]: ...
    async def call(self, tool_id, arguments, runtime_context) -> ExternalToolResult: ...
```
`AgentOutcome`: response, serialized_new_messages, usage, traces. Format serialized messages jest własnością HistoryCodec adaptera, nie domeny. `StoredRequest`: input_hash,result. Hash obejmuje prompt, attachment hashes i ustawienia efektywne, nie sekrety. `SessionRepository.commit` sprawdza CAS i zapisuje wszystkie dane atomowo; load zwraca kopię.
`AttachmentStore`: put(owner_id,bytes,metadata)→AttachmentRef; get(owner_id,id)→bytes; delete. `ExternalToolSpec`: tool_id, description,input_schema,output_schema|null,server_id,effect=read|write|unknown. `ExternalToolResult`: status=ok|error|unavailable|denied,content,source_refs,truncated,diagnostics. ExternalToolSpec nie importuje Tool z SDK.
Dodatkowe command DTO implementuj z identycznymi polami operation_id/expected_working_revision/reason/source_id co MutationCommand. ImportCommand ma staged_artifact_id,mode=replace; CollectionCommand ma path,items. API repo lease może być prywatnym adapterem w MVP; nie wystawiaj blokady LLM.

## Pomocnicze struktury złożonych operacji
`CollectionReplacement`: event_id, operation_id, turn_id, turn_index, path, old_items, new_items, old_entity_ids, new_entity_ids, change_ids. Jest częścią ForgeState.structure_audit; FieldChange pozostaje audytem wartości. TurnResult.diff zawiera FieldChange, a `structure_diff` (default []) zawiera CollectionReplacement. SessionSnapshot zachowuje oba. Dla reorder-only diff może być pusty, structure_diff nie.
`ToolTrace`: call_id, tool_id, effect, status, started_at, finished_at, argument_summary (zredagowany), result_summary, source_ids, error_code|null. Trace nie zawiera reasoning. `OperationAttempt`: operation_id, status, diagnostic_codes, change_ids. TurnRecord.attempts obejmuje także noop/rejected.
`AuditPage`: items:list[FieldChange], next_cursor|null. API inspect_provenance opcjonalnie przyjmuje entity_id dla elementów kolekcji; bez entity_id pointer jest rozwiązywany do bieżącej tożsamości. Osobny tryb historical_pointer wyszukuje dokładnie zapisane dawne adresy.
`AttachmentRef`: id,owner_id,name,media_type,size_bytes,sha256. `StagedArtifact`: id,owner_id,source_id,media_type,payload,sha256,created_at. Registry artefaktów ma trwały adapter lokalny w S15 (SQLite/blob plikowy) i neutralny port application-owned. Nie zmienia to Forge w klienta I/O: narzędzie rozwiązuje ID do zweryfikowanego payload przed wywołaniem engine.import_contract. Engine przyjmuje wewnętrzny ResolvedImportCommand z payload i verified SourceRef, podczas gdy tool publicznie przyjmuje wyłącznie staged_artifact_id.
`SessionSnapshot` przechowuje serialized history jako JSON/bytes kodowane przez HistoryCodec, nie surowe klasy SDK. `history_branches` jest mapą history_id→{message_format_version,messages,turn_boundaries}; history_id zmienia aplikacja, nigdy model.
