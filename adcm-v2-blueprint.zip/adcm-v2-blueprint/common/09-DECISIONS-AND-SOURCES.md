# Decyzje i weryfikacja API

Źródła sprawdzone 2026-10-09. Dokumentacja online jest ruchoma; nie deklarujemy numeru wersji pakietu, którego nie instalowaliśmy. S00 musi przypiąć faktycznie zainstalowaną wersję i potwierdzić wymagane API krótkim offline smoke testem. Ta paczka nie jest przetestowaną implementacją.

| Obszar | Decyzja |
|---|---|
| Structured output | `output_type`, nie historyczny `result_type`; wynik przez `result.output` |
| Historia | `new_messages`, `all_messages`, serializacja oraz ModelMessagesTypeAdapter w adapterze |
| MCP | Preferuj natywny toolset/klienta Pydantic AI zgodny z pinned release; nie własny JSON-RPC |
| Wersje MCP API | Nazwy MCPServerStreamableHTTP i MCPToolset występują w różnych generacjach dokumentacji; S00 wybiera jeden działający zestaw, nie miesza przykładów |
| Agent | Jeden run to wiele kroków narzędziowych, nie jedna mutacja |
| TestModel/FunctionModel | Sprawdzają wykonanie scenariusza, nie rozumienie prawdziwego promptu |
| Przeglądarka | Historia SDK nie zastępuje IndexedDB, repo audytu ani obsługi sekretów |
| Stub | Jawnie wąski schema; nie dowolne pola, nie pseudo-walidacja split-only |
| Commit | Draft tury + atomowy commit; hard failure rollback lokalnego draftu |
| Pełny Forge | Osobna późna faza backendu; zależna od realnych zasobów |
| HTTP/WWW | API późne, WWW ostatnie; wszystkie use cases wcześniej przez CLI/library |

## Źródła pierwotne
- https://ai.pydantic.dev/agents/ — Agent i limity (obecnie przekierowuje do pydantic.dev).
- https://ai.pydantic.dev/output/ — ustrukturyzowane output i tryby wyniku.
- https://ai.pydantic.dev/message-history/ — zarządzanie i serializacja historii.
- https://ai.pydantic.dev/toolsets/ — kompozycja zestawów narzędzi.
- https://ai.pydantic.dev/mcp/client/ — integracja klienta MCP.
- https://ai.pydantic.dev/testing/ — TestModel i FunctionModel.
- https://ai.pydantic.dev/logfire/ — instrumentacja agenta.
- https://docs.cloud.google.com/logging/docs/structured-logging — JSON i pola specjalne logowania.
- https://docs.cloud.google.com/logging/docs/reference/v2/rest/v2/LogEntry — semantyka wpisu logu.

Specyfikacja portów, transakcji, etapów, uprawnień i progów testów jest projektem ADCM, nie twierdzeniem, że biblioteki dostarczają te funkcje automatycznie. Nie wdrażamy najnowszych dodatkowych funkcji SDK tylko dlatego, że są dostępne. Pierwszeństwo ma mała powierzchnia zależności.

## Niewiadome, które nie blokują startu
Rzeczywisty kontrakt i reguły (S28), API/token mapping istniejących MCP (S12), konkretny provider modelu i jego uprawnienia (S00/L3), produkcyjny mechanizm identity i wspólne repo GCP (osobne decyzje wdrożeniowe). Fixtures pozwalają zbudować/testować funkcjonalność wcześniej, ale nie dowodzą integracji z tymi systemami.
