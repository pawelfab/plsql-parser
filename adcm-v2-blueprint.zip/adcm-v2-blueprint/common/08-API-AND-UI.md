# Późne adaptery API, worker i WWW

API: FastAPI `create_app(services)` bez I/O przy imporcie modułu. Lifespan zarządza zasobami. DTO są tymi samymi typami co CLI; zależność auth mapuje caller na owner_id. Lokalne demo auth jest jawnie lokalne, nie tryb produkcyjny. API nie przyjmuje owner_id z niezaufanego JSON jako dowodu tożsamości.

| Metoda i trasa | Zachowanie |
|---|---|
| POST /v1/sessions | Nowa sesja, 201 |
| GET /v1/sessions/{id} | Snapshot/prezentacja, tylko owner |
| POST /v1/sessions/{id}/turns | TurnRequest → TurnResult, 200 także partial/failed domenowe |
| PATCH /v1/sessions/{id}/settings | Ustawienia z expected_revision, nowa rewizja |
| GET /v1/sessions/{id}/export | SessionExport bez sekretów |
| POST /v1/sessions/import | Nowy fork z walidacją danych klienta |
| POST /v1/attachments | Bajty/metadata → AttachmentRef, limity/ownership |
| GET /v1/sessions/{id}/contract.yaml | Czysty YAML lub annotated=true |
| GET /v1/sessions/{id}/provenance?path=... | Stronicowany audyt |
| POST /v1/external-operations/{id}/approve | Jawna zgoda dla przygotowanej operacji |
| GET /health/live, /health/ready | Żywotność i gotowość wymaganych zależności |

Malformed request 422; brak auth 401; access denied 403 lub nierozróżnialne 404; sesja nieistniejąca 404; stale revision/request mismatch 409; oversize 413; infrastruktura storage 503. Business INVALID_VALUE wewnątrz 200 TurnResult, nie wyjątek HTTP 500. `expected_revision` stosuj również do settings. Credentials dostarczane oddzielnym kanałem request/session runtime po TLS i nigdy zwracane w GET; przykładowy adapter akceptuje krótkotrwały credential handle, nie serializuje sekretu w TurnRequest.

Worker: `handle_turn_job(payload, auth_context)` deleguje do tego samego execute_turn i używa request_id. ACK dopiero po trwałym wyniku, duplicate delivery korzysta z repo. Brak brokera w MVP; test fake delivery. Długotrwała durable orchestration wymaga osobnego etapu, nie jest zapewniona samym async def.

WWW końcowe: czat renderujący bloki i bezpieczny Markdown; panel kontraktu; lista sesji; upload; ustawienia osobnych tokenów Jira/Confluence i external writes; oznaczenie zmienionych pól na podstawie diff, komentarze źródła i tury; provenance na klik. YAML komentarze to widok, nie dane wejściowe silnika. Czysty eksport nie zawiera komentarzy. Renderuj strukturę YAML biblioteką z obsługą komentarzy, nie regex doklejającym tekst po liniach. Escape i allowlist linków, brak raw HTML.
W pierwszym WWW wystarczy POST i oczekiwanie na wynik; streaming nie jest warunkiem działania. Opcjonalny SSE jako osobny finał: event seq/run_id, tool_started/tool_finished, text_delta (provisional), turn_committed/turn_failed. Dopiero turn_committed aktualizuje trwały kontrakt. Bez emitowania toku rozumowania. Reconnect najpierw pobiera wynik request_id, nie wykonuje tury drugi raz.
