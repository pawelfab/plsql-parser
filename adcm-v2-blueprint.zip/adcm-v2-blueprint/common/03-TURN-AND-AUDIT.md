# Tura, atomowość i audyt

## Sekwencja normatywna
1. Uwierzytelnij owner_id (CLI lokalny użytkownik). Sprawdź dostęp do sesji i załączników.
2. Zajmij blokadę sesji, sprawdź request_id przed expected_revision. Ten sam request i ten sam hash → poprzedni wynik, zero wywołań modelu. Ten sam ID/inne dane → conflict. Sprawdź CAS.
3. Wczytaj snapshot, utwórz deep copy i TurnContext z turn_index+1. Wyczyść wyłącznie bufor nowej tury, nie historyczny audyt. Brak globalnego mutowalnego engine.
4. Utwórz deps, opcjonalny runtime Forge i katalog narzędzi dozwolonych dla sesji. Zbuduj historię aktywnej gałęzi i uruchom agent.run z limitami.
5. Narzędzia wykonują operacje na kopii roboczej. Odczyty po mutacji widzą nowy stan. Każdy command: kopia kandydata → mutacje → reguły → walidacja → atomowe przyjęcie command. Nieudany command nie cofa wcześniejszego udanego command w tej turze.
6. Po normalnym wyjściu agenta zweryfikuj referencje bloków. Dołącz faktyczny wynik attempts/diff. Zapisywane są wszystkie zaakceptowane commands; częściowo odrzucona tura jest partial.
7. Zapisz dokument + audyt + historię + TurnRecord + request result + revision+1 w jednej transakcji repo. Dopiero po commit wolno komunikować trwały sukces. Nawet tura pytaniowa zwiększa revision i turn_index; diff pozostaje pusty.
8. Zwolnij blokadę i zasoby MCP również przy błędzie/cancel.

## Twarde błędy
Timeout całego agent.run, wyczerpanie limitu, błąd providera i brak poprawnego output po retry: odrzuć WSZYSTKIE zmiany robocze Forge tej tury. Zapisz failed TurnRecord z pustym diff, diagnostyką i bez niekompletnych par tool-call w aktywnej historii. Dopuszczalna deterministyczna wiadomość użytkownika + systemowy wynik niepowodzenia; oryginalne ślady przechowuj jako trace, nie ponownie wykonywalną historię modelu. Następna tura otrzymuje poprzedni kontrakt. Jest to świadoma polityka MVP.
Awaria repo przy commit → brak potwierdzenia zapisu, błąd infrastruktury; klient ponawia z tym samym request_id. Jeśli zapis jednak zakończył się przed zerwaniem połączenia, find_result odzyskuje wynik. Nie ponawiaj całego agenta automatycznie. Awaria procesu przed commit nie zapisuje zmian. Anulowanie przed commit usuwa draft; zwróć cancelled tam, gdzie adapter może; brak nowej trwałej tury, jeśli zapis failure nie jest możliwy.
Zewnętrznych zapisów MCP nie da się cofnąć transakcją SQLite. Patrz 04: osobny dziennik wykonania i status uncertain; nigdy twierdzenie, że rollback lokalny cofnął Jira.

## Audyt kolekcji
Każdy zmieniony liść dostaje FieldChange. Dodanie/usunięcie pustego obiektu lub listy też dostaje zdarzenie kontenera; nie dubluj kontenera zawierającego te same leaf changes. Dla replace_collection zapisuj ponadto CollectionReplacement z old/new całej listy, mapą stabilnych entity_id oraz powiązanymi change_ids. To daje odtworzenie struktury i usuniętych kolumn. UUID elementów pozostają w sidecar entity_ids, nie trafiają do YAML. Dopasuj kolumny po jednoznacznym name w obrębie tabeli; duplikat name → rejected. Zmiana name traktowana jako usunięcie + dodanie. Reorder zachowuje ID i rejestruje zmianę struktury; historyczny pointer jest adresem w chwili zdarzenia, nie wieczną tożsamością kolumny.
Pochodzenie początkowego importu zapisz jako add każdej wartości. Jawny null ma exists=true. Wpisy starych usuniętych kolumn pozostają w audycie. `last_changed_turn` jest projekcją z audytu, nie polem generowanym przez LLM.
Diff odpowiedzi to uporządkowane zdarzenia z bieżącej zatwierdzonej tury. Gdy A→B→A, audyt zachowuje oba zdarzenia, a prezentacja może mieć `net_changed=false`; nie usuwa historii. Ta sama wartość i ten sam typ to NOOP, bez nowego pochodzenia. Różnica bool/int jest istotna.

## Kolejność i granice
Wywołania mutujące serializuj w warstwie agenta; nie wystarczy losowa kolejność zdobywania locka. Jeśli model wyśle kilka naraz, wykonuj w kolejności ToolCallPart z odpowiedzi, identyfikując operation_id przez turn_id + tool_call_id. Wrapper dispatchera lub potwierdzona funkcja sequential w przypiętym SDK musi mieć test kolejności. Odczyty niezależnych MCP mogą działać równolegle. Limit narzędzi uwzględnia próby, nie tylko sukces.
`expected_working_revision` rośnie po applied command, nie po noop/rejected. Powtórzenie operation_id z identycznymi argumentami zwraca zapisany MutationResult; inne argumenty → OPERATION_REUSE_MISMATCH. Nie deduplikuj różnych celów użytkownika tylko dlatego, że mają podobny tekst.

## Przykłady odbioru
- „Ustaw na 25:00 i pokaż opcje orkiestracji”: INVALID_VALUE, brak zmian i nowego audytu pola; get_section_fields nadal działa; odpowiedź zawiera błąd i opcje.
- „Ustaw właściciela i sprawdź Jira”, Jira niedostępna: poprawna zmiana + partial + unavailable, commit lokalny.
- Poprawna zmiana, potem limit pętli: failed, kontrakt bez zmian, diff=[], brak potwierdzenia sukcesu.
- „Co ustawiłem wcześniej?”: inspect/provenance na żądanie; brak mutacji i pełnego audytu w prompt startowym.
