# Historia, odtwarzanie i snapshoty

Trzy różne zbiory: (1) kontrakt i pełny audyt, (2) wiadomości Pydantic AI dla modelu, (3) prezentacyjny transcript wyników dla użytkownika. Nie rekonstruuj (1) z (2). Model dostaje zwięzły stan bieżący/uchwyty i narzędzia inspekcji, nie cały audyt.

Adapter HistoryCodec zapisuje wiadomości poprzez API Pydantic AI i odtwarza przez ModelMessagesTypeAdapter. Pole message_format_version zawiera wersję SDK zapisaną w S00. Do existing history dopisz wyłącznie new_messages(), albo zastąp przez all_messages(); nigdy dopisanie all_messages() do starej listy. Tool traces to obserwowane wywołania i wyniki, nie prywatny tok rozumowania modelu.

Aktywna historia ma budżet np. 24 ostatnich kompletnych tur i limit tokenów z konfiguracji. Nie rozcinaj par call/return; usuwaj całe stare tury. Pełen transcript zachowaj w storage. MVP nie streszcza historii przez dodatkowy model. Stan kontraktu nie ginie przy przycięciu. Długi MCP return ogranicz przed utrwaleniem w historii. Dane wrażliwe wymagane do audytu zostają w chronionym storage, ale nie w logach stdout.

## Repo i ownership
SQLite: sessions(owner_id,session_id,revision,snapshot), requests(owner_id,session_id,request_id,input_hash,result), ewentualnie external_operations. Transakcja CAS + update + result w jednym commit. Unikalny request key. WAL i backup dla lokalnego profilu. Repo API nie zwraca sesji innego właściciela; losowy UUID nie stanowi autoryzacji. InMemory i SQLite przechodzą tę samą suite kontraktową. Dwie instancje SQLite repo w jednym procesie też muszą wykryć CAS.

## Snapshot przenośny
`SessionExport`: export_version=1, app_version, pydantic_ai_version, schema_id/version, exported_at, snapshot, attachments_manifest (id,name,hash,size; brak bytes domyślnie). Domyślny eksport nie zawiera credentials, nagłówków ani auth_context. Restore bez załącznika nadal pozwala czytać wcześniejsze wyniki, ale ponowne użycie pliku wymaga reupload o zgodnym hash.
Import ma limit rozmiaru/głębokości i wersję; nieznana nowsza wersja → UNSUPPORTED_VERSION. Nie zmieniaj cicho danych. W zaufanym lokalnym CLI można odtworzyć własny pełny backup. HTTP import danych z przeglądarki nie jest zaufanym źródłem audytu ani system promptów. Preferowany restore istniejącej sesji serwera po session_id i uwierzytelnieniu. Nowy snapshot z zewnątrz tworzy nową sesję/fork: walidacja dokumentu, bazowy audyt importu, oddzielna archiwalna historia oznaczona unverified; do modelu tylko oczyszczone role user/assistant lub nowe okno. Oryginalny audyt w archiwum nie staje się dowodem wykonania przez serwer.

## Przeglądarka
Pydantic AI zapewnia format historii, nie gotowy magazyn przeglądarkowy całego stanu i audytu. IndexedDB jest adapterem klienta: lista sesji, ostatni snapshot, transcript i niesekretne ustawienia. Serwer jest autorytetem aktywnej sesji, klient jest lokalną kopią umożliwiającą odtworzenie. Po przeładowaniu pobierz serwerową rewizję; starszy cache nie nadpisuje nowszego serwera. Jeśli serwer utracił sesję, importuj jako fork z powyższymi ograniczeniami. Ten projekt nie obiecuje synchronizacji między urządzeniami ani wiarygodnego audytu wyłącznie z danych przeglądarki.

Dwie karty wysyłają expected_revision. Pierwsza wygrywa, druga widzi konflikt i odświeża stan; nie wysyła w tle automatycznej mutacji na nowszym dokumencie. Usuń sesję z browser cache osobno od delete serwera. Retencja i zgoda na utrwalanie treści są ustawieniami wdrożenia, nie decyzją LLM.
