# Forge: stub teraz, pełny silnik później

## Stały publiczny interfejs
Interfejs 02 obejmuje discovery, inspect, apply, replace_collection, import, validate, provenance i snapshot. Trzy metody z pierwotnego przykładu nie wystarczą do kopiowania, usuwania i audytu. Ustalamy szerszy port już teraz, aby pełny silnik zmieniał implementację, nie agent/CLI/API. Eksport YAML to serializer nad snapshot.doc; komentarze są projekcją audytu.

## Demonstracyjny schemat stub v1
| Pointer | Typ / zasady |
|---|---|
| /metadata/name | string, niepusty, wymagany do complete |
| /metadata/owner | string, opcjonalny |
| /orchestration/engine | cloud_composer albo cloud_workflows |
| /orchestration/schedule | string, dokładnie 5 pól cron, minuty 0–59 i godziny 0–23 |
| /orchestration/timezone | nazwa IANA, domyślnie UTC w ustawieniach, nie automatyczny wpis w doc |
| /bronze/storage_bucket | string z prefiksem gs:// i niepustą nazwą |
| /bronze/retention_days | integer >=1, bool niedozwolony |
| /silver/tables | lista obiektów tabel; replace_collection/import |
| /silver/tables/{i}/name | unikalny niepusty string |
| /silver/tables/{i}/columns | lista {name:string,type:string}, name unikalny w tabeli |

Typ kolumn w stub: STRING, INTEGER, NUMERIC, BOOLEAN, DATE, TIMESTAMP. PK i pochodne converter→silver nie są zaimplementowane w stub. Główne sekcje metadata, orchestration, converter, bronze, silver, gold. converter/gold są informacyjne: discovery zwraca brak obsługiwanych pól; mutacja unknown → rejected. Nie przyjmuj dowolnego słownika tylko dlatego, że istnieje sekcja.
Cron stub obsługuje wyłącznie `*` lub pojedyncze liczby w każdym z 5 pól, zakresy minute 0..59/hour 0..23/day 1..31/month 1..12/weekday 0..6. Inne poprawne dialekty cron → UNSUPPORTED_DEMO_FORMAT, a nie twierdzenie, że nie są poprawnym cronem. Dla pełnego silnika wybierz parser zgodny z produkcyjnym kontraktem. Sam split na 5 elementów nie jest walidacją godziny.
Nie zgaduj częstotliwości ani strefy: „codziennie o 21 UTC” → `0 21 * * *`; samo „o 21” bez kontekstu częstotliwości → pytanie doprecyzowujące. „25:00” → błąd, nigdy automatyczna korekta na 02:00. DST i czas lokalny są sprawą ustawionej IANA zone, nie stałego offsetu.
Stub może przyjąć niekompletny poprawny dokument. Brak /metadata/name → valid=true,complete=false. Nieznane pola/type errors → valid=false. Odrzucone mutacje nie zatruwają bieżącego dokumentu. Warunkowy demo field: /orchestration/retry_count integer 0..10 dostępny wyłącznie przy engine=cloud_composer. Przy usunięciu/zmianie engine bez usunięcia retry_count command zostaje odrzucony; batch zmieniający oba jest poprawny. To testuje realne boundary bez implementacji x-rules.

## Kopiowanie i załączniki
Pipeline z MCP pobierz jako zarejestrowany artefakt (source_id, id, version/hash), nie jako ręcznie przepisany przez LLM YAML. `stage_artifact` przechowuje payload po stronie aplikacji i daje staged_artifact_id. `forge_import_contract` przyjmuje ten ID; sprawdza owner, hash, zgodność i atomowo zastępuje doc (replace). Nie obsługujemy domyślnego merge. Jeśli user nie określi, czy zastąpić istniejący niepusty kontrakt, zapytaj. Pipeline wybierany po jednoznacznym ID; nie po pierwszym podobnym wyniku.
Nie każdy MCP zwraca jednakowy format. Deklaratywne mapping JSON Pointer w konfiguracji extraction wskazuje payload pipeline'u i jego id/version. Ogólne pobieranie narzędzi pozostaje automatyczne; specjalne kopiowanie wymaga zgodnego formatu albo deklaratywnego mapowania. Nie pisz adapterów nazwanych SAP/Jira w domenie.
Kolumny CSV/TSV/JSON z załącznika lub wklejki przechodzą parser i preview; LLM rozpoznaje cel i format, parser wyznacza dane. Minimalne nagłówki name,type, bez OCR/PDF/XLSX. User „usuń wszystkie kolumny i ustaw te z pliku” wywołuje pojedynczy replace_collection; błąd jednej kolumny zachowuje całą starą listę. Usuwanie wszystkich kolumn bez dodawania jest jawnie wspierane; może dać complete=false.

## Pełny silnik: bramka wejściowa
W S28 wymagane: rzeczywisty contract.json i $defs, wersja JSON Schema, x-contract-rules z opisem wykonania, ux_rules.json, przykłady valid/invalid/incomplete, warunkowe pola i wzorce enrichment. Nie ma tych plików w paczce. S28 może zakończyć się BLOCKED wyłącznie dla pełnego silnika; działający stub i asystent pozostają użyteczne.
Pełny Forge zachowuje separację valid/complete, ponowną walidację kandydata oraz dwustopniowe odkrywanie. JSON Schema waliduje struktury, osobny deterministyczny interpreter obsługuje udokumentowane rozszerzenia. Zakaz eval/exec i wykonywania kodu reguł pobranego z pliku. Nie udawaj obsługi nieznanego rule keyword.
Docelowa kolejność wartości: user > enrichment systemowy > enrichment ogólny > default. To polityka startowa do potwierdzenia fixture'ami S28; user-explicit nigdy nie zostaje nadpisany po cichu. Każda automatyczna zmiana ma rule_id i źródło. Cykl reguł lub przekroczenie limitu propagacji → rollback command, nie częściowy zapis. Deterministyczny stan nie zależy od kolejności kluczy JSON.
Zewnętrzne sprawdzenia nie są I/O silnika: application zbiera facts przez port i podaje immutable facts do walidacji. Forge nie wywołuje MCP. Brak faktów oznacza deferred/unknown diagnostykę, nie fałszywe valid potwierdzające zewnętrzne istnienie tabeli.
