# Architektura i granice

Jeden dystrybuowany pakiet `adcm`, jeden proces usługi. Instalowalne extras `api` i `telemetry`; CLI nie wymaga FastAPI. Zwykłe konstruktory stanowią DI. Pydantic 2 może służyć do DTO; domena nie zna modeli SDK agenta.

```text
src/adcm/
  domain/             # neutralne DTO sesji, zdarzeń i błędów
  ports/              # Protocol; brak implementacji I/O
  application/        # TurnService, SessionService, importy, plugin provider
  agent/              # Pydantic AI runner, deps, tools, history codec, prompt
  forge/              # czysta domena, stub oraz później pełny engine
  adapters/
    memory/           # repo do testów
    sqlite/           # trwałe repo lokalne
    mcp/              # konfiguracja, discovery, wywołania i polityki
    cli/              # interaktywny i --json
    worker/           # handler wiadomości bez brokera
    http/             # późniejsze FastAPI
    telemetry/        # logging i opcjonalne OTel
  bootstrap.py        # jedyne miejsce składania implementacji
web/                  # opcjonalny klient, tworzony na końcu
```

Kierunek zależności: adaptery → application/ports/domain; application → ports/domain/forge interfejs; agent → application DTO/ports; forge → domain/standardowe biblioteki walidacyjne. `bootstrap` może znać wszystkie implementacje. Application używa AgentRunnerPort; nie importuje FastAPI, SQLAlchemy, MCP SDK. Port narzędzi zewnętrznych zwraca neutralne opisy/uchwyty, a adapter agenta zamienia je na toolset Pydantic AI.

## Minimalne porty
Nie twórz osobnego portu dla każdej funkcji. Stabilne granice: SessionRepository, AgentRunnerPort, ExternalToolsPort, AttachmentStore, ForgeEngine, DomainPluginProvider. Zegar i generator ID przekazuj funkcjami dla testów. Logowanie infrastrukturalne nie zastępuje audytu w repozytorium.

## Plugin Provider
`DomainPluginProvider` ma plugin_id, version, create_state() i create_runtime(state, context). Zwraca neutralny runtime z opisami narzędzi i prompt_fragment. Binding Pydantic AI jest w `agent/forge_tools.py`, poza czystym Forge. Dla MVP jedynym pluginem jest Forge, wybierany przez bootstrap; bez dynamicznego importowania kodu z konfiguracji.
`AgentDeps` zawiera TurnContext, optional ForgeRuntime, ExternalToolsPort, AttachmentStore i rejestr SourceRef. Żadne sekrety nie są polami serializowalnego SessionSnapshot. ForgeRuntime zawiera kopię roboczą dokumentu i bufor zmian wyłącznie jednej tury.

FORGE_ENABLED=false oznacza brak runtime'u Forge, narzędzi i promptu Forge. Przy przełączeniu istniejącej sesji zachowaj dane w storage, ale utwórz nową gałąź historii modelu bez wiadomości narzędzi Forge i treści kontraktu. Zachowaj stary transcript do odczytu użytkownika. Nowa gałąź nie przesyła dawnych wiadomości; nie obiecuj usunięcia słów o kontrakcie z bieżącego promptu użytkownika. Ponowne włączenie odtwarza domenę, nie odtwarza automatycznie starego kontekstu modelu.

## Bezstanowe wejścia, stanowa sesja
Publiczne `await TurnService.execute_turn(request, auth_context)` jest wspólne dla wszystkich adapterów. CLI, worker i HTTP nie implementują reguł. `run_sync` wyłącznie w synchronicznym entrypoincie; w aktywnej pętli asyncio używaj await.
Nie rekonstruuj agenta z globalnie mutowanych list tools. Fabryka składa izolowaną konfigurację per tura. Klient modelu może być współdzielony, lecz deps, poświadczenia MCP i bufory nigdy. Discovery może mieć cache TTL; nie odpytuj wszystkich serwerów od zera przy każdej turze.

## Trwałość i wdrożenie
Memory jest testowe; SQLite jest implementacją lokalną, pojedynczy proces. Nie przedstawiaj SQLite na efemerycznym dysku Cloud Run jako trwałej bazy. Do skalowanego GCP potrzebny będzie osobny adapter współdzielonego repo z CAS/lease, poza zakresem początkowej paczki. Logs stdout działają w GCP niezależnie od wyboru bazy. Cloud Run/GKE mają zbieranie logów w obsługiwanych konfiguracjach; na Compute Engine skonfiguruj Ops Agent. Nie wdrażaj automatycznie niczego do chmury.
