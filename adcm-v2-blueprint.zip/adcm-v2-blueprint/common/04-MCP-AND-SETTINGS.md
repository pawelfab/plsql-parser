# Dynamiczne MCP i ustawienia

## Konfiguracja
Jedna przestrzeń `MCP__<ID>__<KEY>`; ID: [A-Z][A-Z0-9_]*. Parser odkrywa ID z kluczy, bez listy hard-coded serwerów. Klucze: ENABLED, TRANSPORT (streamable_http|stdio), URL, COMMAND, ARGS_JSON, TOOLS_JSON (allowlist), WRITE_TOOLS_JSON, AUTH_PROFILE, TIMEOUT_SECONDS, REQUIRED, DISCOVERY_TTL_SECONDS. Nieznany klucz → błąd konfiguracji; nieznany serwer → normalne discovery. `.env` jest tylko źródłem env w development. Sekrety osobnymi referencjami, nigdy w przykładach repo.

```dotenv
FORGE_ENABLED=true
FORGE_ENGINE=stub
MCP__ATLASSIAN__ENABLED=true
MCP__ATLASSIAN__TRANSPORT=streamable_http
MCP__ATLASSIAN__URL=https://mcp.example.invalid/mcp
MCP__ATLASSIAN__TOOLS_JSON=["search","get_page","get_issue"]
MCP__ATLASSIAN__WRITE_TOOLS_JSON=[]
MCP__ATLASSIAN__AUTH_PROFILE=atlassian_user
MCP__ATLASSIAN__TIMEOUT_SECONDS=15
MCP__ATLASSIAN__REQUIRED=false
MCP__ATLASSIAN__DISCOVERY_TTL_SECONDS=300
```
Nazwy w przykładzie są fixture, nie potwierdzone nazwy narzędzi serwera użytkownika. W S12 administrator wpisuje rzeczywiste nazwy z discovery. Nowy zgodny MCP wymaga wyłącznie konfiguracji i restartu; hot reload poza MVP. Nowy niestandardowy transport/auth flow może wymagać adaptera. „Bez zmian kodu” nie oznacza obsługi każdego przyszłego protokołu.

## Discovery i wywołania
Połącz standardowego klienta MCP, pobierz listę narzędzi, filtruj allowlist i uprawnienia, waliduj input schema, nadaj stabilny namespace `mcp_<server_id>__<tool_name>` (jeżeli limit nazw modelu wymusza skrót, trzymaj odwracalny rejestr). Nie zgaduj read/write z nazwy. Unknown effect blokowane domyślnie; administrator klasyfikuje dopuszczone read i write. Annotations MCP mogą pomagać, ale nie są samodzielnym uprawnieniem.
Brak TOOLS_JSON oznacza brak dopuszczonych tools, nie wildcard. Pusta lista wyłącza tools serwera. Brak narzędzia z allowlist → diagnostyka; REQUIRED=true blokuje start, optional degraduje. Niedostępny optional serwer nie blokuje Forge ani innych MCP. Token 401 jednej osoby nie unieważnia katalogu wszystkich użytkowników.
Cache schematów kluczowany konfiguracją i zakresem autoryzacji, TTL 300s. Nie współdziel cache wyników/stron pomiędzy użytkownikami bez dowodu identycznych ACL. W MVP cache tylko katalogu i memoizacja read w obrębie tury. Wyniki ograniczaj do 32 KiB na tool, jawne truncated i źródło; nie twierdź, że skrót jest całym dokumentem. Maks. 80 eksponowanych tools; przekroczenie daje błąd konfiguracji z prośbą o allowlist, nie losową selekcję.
Async lifecycle przez context manager; close w finally. HTTP preferowany, stdio tylko komendy administratora z listy, bez shell=True. stdout procesu MCP należy do protokołu; jego diagnostyka do stderr. Zmiana użytkownika nie może odziedziczyć nagłówków poprzednika.

## Wiedza i łańcuch narzędzi
LLM widzi opisy i schematy aktualnie dopuszczonych narzędzi. Nie budujemy statycznego routera słów „Jira”, „SAP”. Może kolejno resolve_system → get_schema, bazując na wyniku. Wiedza MCP może opisywać praktyki, ale tylko lokalny Forge decyduje, czy pole jest dozwolone w bieżącym kontrakcie. Cache hit nie dowodzi kompletności. Jeśli MCP zwraca source/cache/truncated/coverage, przenoś je do źródeł; jeśli nie zwraca, oznacz zakres unknown. Nie dopisuj domniemanej kwerendy zdalnej.

## Poświadczenia i zapis
`CredentialContext` żyje poza SessionSnapshot, historią i logami. Przechowuje osobne tokeny Jira i Confluence, mapowane do transportu MCP według jego rzeczywistego kontraktu. Nie zakładaj, że dowolny serwer potrafi przyjąć token Jira w nagłówku Authorization: może wymagać nagłówków dedykowanych albo sam uwierzytelniać użytkownika. Deklaratywne mapowanie nagłówków do credential slots obsługuje typowy przypadek; brak zgodności → integration blocked, bez przesyłania tokenu w tool arguments.
WWW pamięta ustawienia niesekretne i zaszyfrowane tokeny w IndexedDB. Klucz wyprowadzany z hasła użytkownika nie jest zapisywany; po odświeżeniu wymaga odblokowania. Domyślnie token tylko w pamięci karty. Przy opcji „zapamiętaj” AES-GCM z losowym nonce i wersjonowanym KDF; jest to ochrona danych na dysku, nie ochrona przed aktywnym XSS. Eksport sesji wyklucza tokeny. Nie zapisuj tokenów jawnie w localStorage. CLI przyjmuje env/ukryty prompt, nigdy argument process list.

Efektywne write = global allow AND sesyjne external_writes_enabled AND tool allowlist AND uprawnienia zewnętrznego API. Sprawdź przed ekspozycją i ponownie przed call. Sam przełącznik nie autoryzuje dowolnej intencji ze strony Confluence. W S24 dodaj explicit user approval operation_id (CLI/HTTP), dla zewnętrznych zapisów. Opis operacji i argumenty muszą być widoczne przed zgodą. Nie dotyczy zwykłych lokalnych zmian kontraktu.
Przed remote write zapisz osobny trwały execution ledger: prepared→approved→started→succeeded|failed|uncertain. Idempotency key przekazuj tylko gdy serwer wspiera. Timeout po wysłaniu bez statusu = uncertain, brak automatycznego retry. Przy twardym błędzie agenta lokalny Forge rollback, lecz zewnętrzny sukces pozostaje w ledger i odpowiedzi. MVP do S23 eksponuje wyłącznie read.
