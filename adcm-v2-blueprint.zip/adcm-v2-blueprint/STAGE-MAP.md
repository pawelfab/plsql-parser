# Mapa etapów

Domyślnie wykonuj po kolei; zależności poniżej są minimalnymi wymaganymi interfejsami. PASS zależności nie upoważnia do pracy równoległej w tych samych plikach.

| Etap | Cel | Zależności |
|---|---|---|
| [S00](stages/S00.md) | Szkielet i zgodność zależności | — |
| [S01](stages/S01.md) | DTO domenowe i porty | S00 |
| [S02](stages/S02.md) | Repozytorium pamięciowe i semantyka CAS | S01 |
| [S03](stages/S03.md) | Stub Forge: discovery i walidacja odczytowa | S01 |
| [S04](stages/S04.md) | Stub Forge: atomowa mutacja i audyt | S03 |
| [S05](stages/S05.md) | Plugin Provider i deps | S02, S04 |
| [S06](stages/S06.md) | Orkiestracja tury z fake runnerem | S05 |
| [S07](stages/S07.md) | Pydantic AI: runner i narzędzia Forge | S06 |
| [S08](stages/S08.md) | Historia i limity run | S07 |
| [S09](stages/S09.md) | CLI oraz publiczne API biblioteki | S08 |
| [S10](stages/S10.md) | SQLite i trwały restart | S09 |
| [S11](stages/S11.md) | Dynamiczny parser konfiguracji MCP | S10 |
| [S12](stages/S12.md) | Klient MCP i discovery toolsets | S11 |
| [S13](stages/S13.md) | Izolacja auth i polityka read-only MCP | S12 |
| [S14](stages/S14.md) | Tury wiedzy i cele mieszane | S13 |
| [S15](stages/S15.md) | Rejestr artefaktów i kopiowanie pipeline | S14 |
| [S16](stages/S16.md) | Atomowe kolekcje i historia kolumn | S15 |
| [S17](stages/S17.md) | Załączniki i parser wklejonych kolumn | S16 |
| [S18](stages/S18.md) | Bloki odpowiedzi i referencje semantyczne | S17 |
| [S19](stages/S19.md) | Eksport YAML i komentarze audytowe | S18 |
| [S20](stages/S20.md) | Backup sesji i restore | S19 |
| [S21](stages/S21.md) | Logi JSON i ślad narzędzi | S20 |
| [S22](stages/S22.md) | Opcjonalna telemetria i odporność | S21 |
| [S23](stages/S23.md) | Evals i bramka kompletnego MVP | S22 |
| [S24](stages/S24.md) | Kontrolowany zapis zewnętrzny MCP | S23 |
| [S25](stages/S25.md) | Adapter worker bez brokera | S24 |
| [S26](stages/S26.md) | Cienkie API REST | S25 |
| [S27](stages/S27.md) | Pakowanie i odbiór headless | S26 |
| [S28](stages/S28.md) | Wejścia pełnego Forge i testy zgodności | S27 |
| [S29](stages/S29.md) | Pełny Forge: schema loader i walidator | S28 |
| [S30](stages/S30.md) | Pełny Forge: discovery zależne od stanu | S29 |
| [S31](stages/S31.md) | Pełny Forge: reguły i enrichment | S30 |
| [S32](stages/S32.md) | Podmiana silnika i odbiór pełnego Forge | S31 |
| [S33](stages/S33.md) | WWW: czat i widok kontraktu | S32 |
| [S34](stages/S34.md) | WWW: zapis sesji i ustawień w przeglądarce | S33 |
| [S35](stages/S35.md) | Opcjonalny streaming i odbiór końcowy | S34 |

## Kamienie milowe

- M1 / S09: agent + stub + CLI/library, działające tury.
- M2 / S14: dynamiczne MCP, wiedza, cele mieszane.
- M3 / S23: headless funkcjonalność, załączniki, copy, restore, logs i evals.
- M4 / S27: API i uruchamialny pakiet; wersja użyteczna ze stubem.
- M5 / S32: pełny Forge oparty na dostarczonych produkcyjnych zasobach.
- M6 / S35: opcjonalny panel WWW, zapis przeglądarkowy i końcowy odbiór.

S24 włącza zewnętrzne zapisy po domyślnym trybie read-only. S25 nie instaluje brokera. S35 streaming jest opcjonalny, końcowy odbiór obowiązkowy dla realizowanego WWW.
