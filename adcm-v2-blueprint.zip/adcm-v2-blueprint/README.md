# ADCM v2 — pakiet etapów dla osobnych sesji LLM

To dokumentacja budowy nowej aplikacji; nie zawiera implementacji ani deklaracji, że testy aplikacji już wykonano.

## Zacznij tutaj

1. Rozpakuj do nowego repo jako `docs/blueprint/` albo zostaw poza repo i podawaj ścieżkę sesjom.
2. Pierwszej sesji przekaż [PROMPT-START.md](PROMPT-START.md) z `STAGE_ID=S00`.
3. Każdej następnej sesji daj ten sam prompt, common/00-CONTEXT.md, common/01-ARCHITECTURE.md i jeden plik stages/SNN.md. Plik etapu wskazuje dodatkowe specyfikacje; nie trzeba czytać całej paczki.
4. Przechodź dalej po PASS i raporcie handoff. STATUS.json jest startowo NOT_STARTED dla wszystkich etapów.
5. Nie zlecaj całej paczki jednemu małemu modelowi. Granicę pracy wyznacza stage, nie limit tokenów.

## Zawartość

- `common/`: kontekst, architektura, stabilne kontrakty, semantyka tury, MCP, storage, Forge, testy, API i źródła.
- `stages/`: 36 etapów S00–S35, każdy z wejściami, boundary, zakazami, testami i odbiorem.
- `examples/`: demonstracyjne dane i scenariusze do implementacji testów, nie schemat produkcyjny.
- `handoffs/`: statusy, szablon raportu i rejestr decyzji.
- `STAGE-MAP.md`: zależności i kamienie milowe.
- `REQUIREMENTS-MATRIX.md`: pokrycie wymagań.

## Najważniejsze decyzje

Jeden agent i jeden serwis; Forge jako wewnętrzny plugin, zewnętrzne MCP konfigurowane dynamicznie. Najpierw użyteczny headless MVP na stubie. API później, pełny Forge w S28–S32 jako ostatnia faza backendu, WWW w S33–S35. Tura może jednocześnie pytać i zmieniać kontrakt. Historia SDK, audyt i dokument to osobne dane. Mutacje pracują na kopii tury; commit jest atomowy, hard failure cofa lokalny draft.

Rzeczywiste contract.json/x-rules/ux_rules nie zostały dostarczone. S28 jest bramką ich pozyskania. Można zakończyć po S27 i używać działającej aplikacji ze stubem. Jeśli pełny Forge jest zablokowany, właściciel może jawnie wybrać realizację S33 na S27 ze stubem; wtedy oznacz M5 jako BLOCKED, nie „pełny silnik ukończony”. Domyślna kolejność pozostaje S00→S35.

Uwaga o wielkości: etapy są małe względem odpowiedzialności, nie obietnicą czasu pracy. S31 zależy od nieznanej liczby reguł produkcyjnych i zawiera procedurę dalszego podziału po S28. Implementacja nie może wymyślać nieudokumentowanych reguł.
