# Obowiązująca architektura i mapa plików
```mermaid
flowchart TD
 I["Kod + DDL + kontekst"] --> P["Source inventory i ANTLR"]
 P --> G["Gate definicji"]
 G --> S["Analiza SQL, typów i control flow"]
 S --> R["Pełny źródłowy IR"]
 R --> E["ExchangeIR → projekt C"]
 R --> B["Opis biznesowy LLM"]
```
Gate blocking udostępnia jedynie reports/provisional source inventory. Nie prowadzi do finalnego IR.

```text
plsql-ir/
  pyproject.toml
  uv.lock
  README.md
  .env.example
  .gitignore
  docs/                       # ten pakiet
  docs/adapter-spec/          # grammar node → IR i handler support
  docs/decisions/
  config/builtin_registry.json
  config/support_matrix.json
  scripts/generate_antlr.py
  scripts/verify_artifact.py
  vendor/grammars-v4/         # pinned grammar, base classes, licences
  src/plsql_ir/
    domain/identity.py
    domain/source_models.py
    domain/schema_models.py
    domain/program_models.py
    domain/sql_models.py
    domain/exchange_models.py
    domain/business_models.py
    domain/diagnostics.py
    domain/ports.py
    application/import_service.py
    application/preflight_service.py
    application/analysis_service.py
    application/exchange_service.py
    application/business_context.py
    application/business_service.py
    application/artifact_service.py
    adapters/source/reader.py
    adapters/oracle/sql_script.py
    adapters/oracle/ddl.py
    adapters/antlr/generated/   # reproducible generated code only
    adapters/antlr/parser.py
    adapters/antlr/visitor.py
    adapters/oracle/symbols.py
    adapters/oracle/dependencies.py
    adapters/oracle/types.py
    adapters/oracle/control.py
    adapters/oracle/calls.py
    adapters/oracle/dynamic_sql.py
    adapters/sql/sqlglot_adapter.py
    adapters/sql/queries.py
    adapters/sql/dml.py
    adapters/sql/expressions.py
    adapters/storage/json_repository.py
    adapters/llm/pydantic_agent.py
    adapters/llm/prompts.py
    cli.py
    settings.py
  tests/unit/
  tests/integration/
  tests/contract/
  tests/acceptance/
  tests/fixtures/synthetic/
  tests/fixtures/real/         # private/ignored
  data/raw/                   # ignored
  data/artifacts/<analysis_id>/
  data/business/<description_id>/
```
Skrócone domain/adapters/application ścieżki stage są względne do src/plsql_ir. config/docs/scripts/tests to ścieżki repo root. Domain nie importuje ANTLR, SQLGlot, LLM ani storage. Application zależy od domain i portów; adaptery implementują porty. cli/settings składają dependencies. Import modułu nie przetwarza źródeł i nie łączy z siecią.

## Porty
SourceReader.read(input_dir)->InputBundle; PlSqlParser.parse(SourceFile)->SyntaxInventory; DdlParser.parse(SourceFile)->SchemaObject[]; SchemaCatalog.resolve(Reference,Scope)->Resolution; SqlAnalyzer.analyze(statement,context,catalog)->StatementAnalysis; ArtifactRepository.write_staged(artifact)->analysis_id i publish(id), read(id)->Artifact; ExchangeExporter.export(Artifact)->ExchangeIR; BusinessModelPort.describe(ContextPacket)->BusinessDraft. Porty używają modeli domain, nigdy AST bibliotek. SyntaxInventory zawiera provisional nodes/references/diagnostics, nie semantyczny final.
Analyzer korzysta z niezmiennego SchemaIR + symbol table. Publikacja IR i biznesowego opisu oddzielna: awaria LLM nigdy nie unieważnia deterministycznego IR. Nie tworzyć jednego wielkiego parser.py, utils.py ani global graph adaptera w tym repo. Nowe moduły tylko po decyzji docs/decisions i aktualizacji tej mapy.

## Uzupełnienia mapy (obowiązujące)
Root scripts/export_oracle.sql; config/input-manifest.schema.json; reports/<run_id>/preflight.json i provisional-inventory.json (ignored, nie final artifacts); data/raw niezmienne. Stage04b DDL decode typed inventories w adapters/oracle/ddl.py; inventory JSON reader w adapters/source/reader.py. Stage01 generuje schemas w docs/schemas/ oraz input config mirror w config/input-manifest.schema.json z jednego modelu, nie dwóch niezależnych definicji.
SourceRead for root input-manifest.json: reader archiwizuje także manifest jako role context SourceFile. SourceFile.hash obliczany na original bytes, parser normalized manifest creates separate context_hash. Inventory parser converts identifiers and attestations with config provenance. Export pipeline generates attestations user operator verifies; syntetyczne descriptor zawsze oznacza mode synthetic.
