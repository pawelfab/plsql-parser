# PL/SQL → pełny IR → opis biznesowy LLM
Dokumentacja wykonawcza niezależnego projektu `plsql-ir`. Nie jest implementacją parsera. Czytaj w kolejności:
1. [Kontekst i wynik](00-CONTEXT.md).
2. [Architektura i mapa repozytorium](01-ARCHITECTURE.md).
3. [Reguły pracy i odbioru](02-EXECUTION.md).
4. [Wejście i eksport Oracle](03-ORACLE-INPUT.md).
5. Kontrakty: [IR](contracts/IR.md), [wymiana](contracts/EXCHANGE.md), [opis biznesowy](contracts/BUSINESS.md).
6. [Roadmapa](04-ROADMAP.md) i jeden wskazany plik stage na raz.
7. [Macierz testów](05-TESTS.md), [źródła](06-SOURCES.md), [review](review/REVIEW.md).

Pierwszy wynik użyteczny: inwentaryzacja kodu i definicji z brakiem utraty treści, następnie semantyczny IR dla podstawowych SELECT/INSERT. Później DML/control flow i kontrakt wymiany dla trzeciego projektu. Opis biznesowy jest osobnym, wersjonowanym artefaktem LLM.
Dotychczasowy pakiet PowerCenter opisuje także graf/API/LLM i nie realizuje jeszcze kontraktu wymiany v1 z tej dostawy. Kompatybilność wymaga jego adaptera i odbioru kontraktowego; nie deklarujemy jej na podstawie podobnych nazw pól.
