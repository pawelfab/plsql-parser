# Reguły wykonania i odbioru
Wykonawca czyta kontekst, architekturę, wejście, trzy kontrakty i własny stage. Jeden stage=odbieralny zakres. PASS poprzednich zależności wymagany. Zmiany modeli dozwolone tylko zgodnie z versioning/migration contract, nie przez osłabianie walidacji testów.

## Status implementacji a status analizy
Stage outcome: PASS_SYNTHETIC, PASS_REAL, FAIL, BLOCKED. Techniczne stage akceptują PASS_SYNTHETIC dependencies, propagują ten tryb. Real acceptance stage wymaga real code+DDL oraz review operatora. Brak danych firmy nie blokuje tworzenia fixtures, ale nie pozwala nadać PASS_REAL. Status runtime artifact: STAGED, BLOCKED_MISSING_DEFINITIONS, BLOCKED_DEPENDENCY_DISCOVERY, INVALID_INPUT, ANALYZED_PARTIAL, ANALYZED_COMPLETE, FAILED. Definicje kompletne to obowiązkowy gate; unsupported semantyka po gate daje PARTIAL, nigdy COMPLETE.

## Raport odbioru stage
Ścieżka docs/acceptance/stage-ID.md. Wymagane: stage ID, commit, inputs/hashes, mode, pliki zmienione, spełnione kryteria z dowodem, komendy i exit code, golden fixture IDs, unresolved/gaps, reviewer verdict, next permitted stage. PASS tylko przy każdym kryterium. Brak wymaganego zewnętrznego input=BLOCKED, błąd kodu=FAIL. Kolejny stage nie może traktować unresolved jako rozpoznane.

## Wymogi review i źródeł
Reviewer czyta kod, fixtures i wyniki testów. Oczekiwane golden IR przygotowane ręcznie niezależnie od parsera. Każdy handler ma docs/adapter-spec wpis: grammar rule, source range, expected IR, Oracle version/Guide section, fixture i unknown behavior. Brak dowodu semantyki=opaque+diagnostic. Nie używać LLM jako normalnego parsera ani recovery zmieniającego facts IR.

## Zakres i praca z artefaktami
Nie wykonuj SQL/PLSQL z analizowanego wejścia. Export z Oracle jest oddzielnym read-only narzędziem operatora, nie parserem. Runtime i CI offline dla deterministic pipeline po zainstalowaniu dependencies. Firmowe źródła, SQL, DDL i parametry poza publicznym git. Business external provider default disabled; jawna konfiguracja operatora włącza wysyłkę do wybranego modelu. Dostawa zawiera dokumentację, nie działający parser, pełną grammar ani generator dbt.

## Przejście prototypu przez etapy odbioru
09b i 11d mogą mieć PASS_SYNTHETIC dla kodu/testów i jednocześnie real_acceptance=BLOCKED w raporcie. Pozwala to kontynuować rozwój następnych stage w trybie synthetic, bez deklaracji realnego odbioru. Stage12 końcowy PASS_REAL wymaga real_acceptance=passed dla obu etapów; w przeciwnym razie wynik całości BLOCKED_REAL i jawny prototyp. Runtime gate definicji nie ma wyjątku synthetic: example musi zawierać komplet definicji albo BLOCKED.
