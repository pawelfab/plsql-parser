# Niezależny review dokumentacji PL/SQL

## Decyzja końcowa: PASS dokumentacji

Reviewer: **osobny model gpt-6-astra**, osobny agent. Odczytano i oceniono wszystkie **51 plików specyfikacji**: 35 plików etapów, trzy kontrakty, osiem dokumentów głównych i pięć plików examples. Po poprawkach ponownie odczytano zmienione kontrakty/dokumenty/etapy/examples oraz wszystkie sześć nowych plików podetapów. Ostatni przebieg uwzględnia wymagane `analysis_mode` i końcowe mapowania deklaracji, parametrów cursorów, clauses i auxiliary IDs.

**P01–P09 zamknięte. Nie pozostały pytania blokujące dostawę dokumentacji.** Normatywne doprecyzowania kontraktów są częścią specyfikacji i muszą być czytane razem z ich modelami podstawowymi. W szczególności końcowy RuleDraft zastępuje wcześniejszy skrót BusinessDraft, a typowane SourceLocators określają ostateczne referencje programu/kontekstu w Exchange.

PASS oznacza spójną dokumentację wykonawczą, nie działający parser, udowodnioną pełną semantykę Oracle ani execution equivalence z dbt. Real Oracle/DDL/operator review i późniejszy prawdziwy adapter PowerCenter są jawnymi bramkami wykonania; nie udajemy ich realizacji. Raport review odczytuje osobno orkiestrator.

Kontrole pomocnicze: obydwa pliki JSON mają poprawną składnię, wszystkie lokalne linki Markdown w pakiecie prowadzą do istniejących plików. Walidacja przyszłymi generowanymi JSON Schema i wykonanie fixtures należą do wskazanych etapów, nie zostały zadeklarowane jako już wykonane.

## Ocena końcowa każdego pliku

Skrót SHA256 identyfikuje treść odczytaną i odebraną w końcowym przebiegu. Każdy wiersz ma osobną ocenę; tabeli nie wygenerowano zamiast merytorycznego odczytu plików.

| Plik | Wynik | Sprawdzone rozstrzygnięcie | SHA256 (12 znaków) |
|---|---|---|---|
| `00-CONTEXT.md` | PASS | Trzy projekty, dowolny porządek technologii, conservation versus semantics. | `ebb5e90aa938` |
| `01-ARCHITECTURE.md` | PASS | Porty i moduły, export/schema/report paths oraz archiwizacja config source. | `b61cfe723b76` |
| `02-EXECUTION.md` | PASS | Technical/real gates i artifact statuses rozdzielone; LLM nie zmienia facts. | `fa12f9d86175` |
| `03-ORACLE-INPUT.md` | PASS | Obowiązkowe DDL, jawny analysis_mode, ddl_order i finite dynamic bindings. | `a8e31ae7916e` |
| `04-ROADMAP.md` | PASS | 35 małych etapów, zależności 08a/08b integration oraz 09b i 02b zgodne. | `adbc9a4fb729` |
| `05-TESTS.md` | PASS | Niezależne goldens, kompletność/source conservation i future executor boundary. | `4cac48ce9fde` |
| `06-SOURCES.md` | PASS | Źródła i wersja baseline nie udają zweryfikowanej zgodności z firmowym Oracle. | `1572002c5df9` |
| `README.md` | PASS | Cel i nawigacja; wcześniejszy PowerCenter nie deklaruje zgodności bez adaptera. | `65f6de85babe` |
| `contracts/BUSINESS.md` | PASS | Normatywny draft/final, statusy, evidence allowlist, scope budgets i immutable revisions. | `929a3a98cac5` |
| `contracts/EXCHANGE.md` | PASS | Neutralne facts; FK remap, type closure, control operations i SourceLocator. | `443a582c3ec7` |
| `contracts/IR.md` | PASS | Typed models/FK/ID, evidence, gate discovery, state, source conservation i CLI. | `a36bdf01acea` |
| `examples/README.md` | PASS | Syntetyczny zakres sample i ręcznie określona oczekiwana logika. | `1f382bc0dedd` |
| `examples/customer_pkg.sql` | PASS | Mały INSERT SELECT przykład zgodny z opisem; nie wykonywano Oracle. | `b7246037d780` |
| `examples/input-manifest.json` | PASS | Poprawny JSON; jawny synthetic mode, pliki, ddl_order i puste bindings. | `350c4f5ab9f6` |
| `examples/inventory.json` | PASS | Poprawny input JSON; object_name i logical package scope zgodne z mapowaniem. | `ebdb9a0e8c25` |
| `examples/schema.sql` | PASS | DDL odpowiada tabelom/kolumnom sample i zachowuje PK/typy. | `0c56f075ad68` |
| `stages/01.md` | PASS | Schema generation i modele v1; brak implementacji przyszłych adapterów. | `21daace4405e` |
| `stages/02a.md` | PASS | Support matrix, Oracle profile i inventory przy jawnym synthetic/real gate. | `808e3d9c9b12` |
| `stages/02b.md` | PASS | Osobny read-only export operatora, kompletność inventory i real test gate. | `2e22c913e73d` |
| `stages/03a.md` | PASS | Source archive, ZIP/path limits, Unicode/CRLF i exact spans. | `707b45532a97` |
| `stages/03b.md` | PASS | Pinned prawdziwy ANTLR, reproducible build i brak false COMPLETE po recovery. | `b0b95f16793f` |
| `stages/03c.md` | PASS | Syntax inventory, opaque fallback, scoped routines i raw preservation. | `1b4d030c1074` |
| `stages/04a.md` | PASS | CREATE/ALTER i typy; jawna semantyczna kolejność DDL z testem negatywnym. | `34ad0efe6786` |
| `stages/04b.md` | PASS | Views/synonyms/types/trigger metadata, evidence i unknown behavior. | `7f9b74eea437` |
| `stages/05a.md` | PASS | Finite dependency closure i discovery-only dynamic hook przed semantyką. | `8197980287b0` |
| `stages/05b.md` | PASS | Obowiązkowy gate, pełny missing report i Analyzer spy także dla dynamic SQL. | `e315d4f4b5f8` |
| `stages/06a.md` | PASS | SQL extraction/binding i brak bibliotecznego AST w publicznym IR. | `85c75b401dd9` |
| `stages/06b.md` | PASS | Oracle expression/type rules oraz jawne unknown/NLS/conversion effects. | `3e27e2a6b815` |
| `stages/06c.md` | PASS | SELECT subset, query tree, distinct value/filter/join/group/rowset dependencies. | `4bfa62b2d2cd` |
| `stages/07a.md` | PASS | INSERT ordinal/default/generated mapping i output values bez cross-product. | `feefbf61ff5e` |
| `stages/07b.md` | PASS | UPDATE old/new occurrences i wspólny prior state dla przypisań równoczesnych. | `bf73f5acaf59` |
| `stages/07c.md` | PASS | DELETE rowset i TRUNCATE/transaction effects rozróżnione. | `b58087cf004a` |
| `stages/07d.md` | PASS | MERGE branch conditions, old state i branch-specific assignments. | `f72a15bc1774` |
| `stages/08a.md` | PASS | Osobny gate integracji control/state/cursors bez nowych handlerów. | `9f679e83da40` |
| `stages/08a1.md` | PASS | Mały etap IF/CASE/return i BranchIR; control oddzielony od data lineage. | `02d595c86d5d` |
| `stages/08a2.md` | PASS | StateVersion/BranchAlternative, kolejne zapisy i test zależności old/new. | `c69c5444fa66` |
| `stages/08a3.md` | PASS | Loops/cursors/fetch, iteration dependency; bulk opaque z zachowanym discovery. | `fa6d6dc7d1c4` |
| `stages/08b.md` | PASS | Osobny gate integracji calls/exceptions/transactions i finite recursion. | `3ccfc3cc6270` |
| `stages/08b1.md` | PASS | Calls/OUT/overloads/package init i ograniczone podsumowanie rekursji. | `8b5afcaacf4d` |
| `stages/08b2.md` | PASS | Named exceptions/WHEN OTHERS/RAISE z alternatywnymi ścieżkami zapisów. | `ede220ff8eb5` |
| `stages/08b3.md` | PASS | Transactions/savepoint/autonomous/side effects bez symulowania runtime. | `ba7e3ecceb1b` |
| `stages/08c.md` | PASS | Dynamic SQL semantyka po wcześniejszym discovery-only gate i derived evidence. | `10e8326acae1` |
| `stages/09a.md` | PASS | Immutable publication, FK/evidence/source checks i jawna obsługa CLI/report. | `0e3b5e9d83d5` |
| `stages/09b.md` | PASS | Real source acceptance ma 09a i 02b; operator/DDL wymagane, gaps dozwolone jawnie. | `17c4983ed60f` |
| `stages/10a.md` | PASS | Deterministyczny Exchange exporter, FK/type closure i blocked rejection. | `1dd57fe4759c` |
| `stages/10b.md` | PASS | Osiem synthetic compatibility cases; rzeczywisty adapter A pozostaje oddzielnym gate. | `85f7e17c9b55` |
| `stages/11a.md` | PASS | Scope-limited deterministic ContextPacket i strukturalny chunking. | `cb995930feaa` |
| `stages/11b.md` | PASS | Typed agent i walidacja IDs/evidence; budgets/failure nie zmieniają source IR. | `3e2db05e1f05` |
| `stages/11c.md` | PASS | Cytowana synteza, status draft/partial, immutable revisions i cache invalidation. | `b2024f99192b` |
| `stages/11d.md` | PASS | Human acceptance biznesowych claims i zakaz invented code facts. | `17ad7d265bec` |
| `stages/12.md` | PASS | Operacyjny odbiór i przyszłe TestSpec/dbt poza implementacją obecnego zakresu. | `7f7f7a375f89` |

## Zamknięcie pytań P01–P09

| Pytanie | Decyzja | Dowód zamknięcia |
|---|---|---|
| P01 | ZAMKNIĘTE | ORACLE-INPUT i IR: wymagany analysis_mode, input/internal inventory mapping, Identifier normalization-only keys, typed scopes i finite bindings; examples dopasowane. |
| P02 | ZAMKNIĘTE | IR: SHA256 raw bytes; Evidence.source_id/rule_version, source/config/derived conditions; manifest archiwizowany jako context source. |
| P03 | ZAMKNIĘTE | IR: Scope/Symbol/Branch/Loop/Cursor/Exception/Assignment/Transaction/Dynamic/Conversion/Clause modele; central IDs i collections/FK, NOCOPY, logical program/spec/body roots. |
| P04 | ZAMKNIĘTE | ORACLE-INPUT/IR/04a: ddl_order niezależne od canonical path sorting i uwzględnione w hash, odwrócona sekwencja daje diagnostic. |
| P05 | ZAMKNIĘTE | IR/05a/05b/08c: discovery-only helper przed gate, monotonic closure, exhaustive variants z evidence, literal missing-table test przed SqlAnalyzer. |
| P06 | ZAMKNIĘTE | IR i 08a2/08b3: output_value_id, symbol/state refs, typed StateTransition, guarded alternatives, unknown row overlap i rollback; dependency endpoints pozostają Value IDs. |
| P07 | ZAMKNIĘTE | EXCHANGE: remap wszystkich lokalnych ID/FK/types, materialized references/type graph, control operations oraz typed SourceLocator do programu/kontekstu. |
| P08 | ZAMKNIĘTE | BUSINESS: final RuleDraft/SummarySegment, local→final mapping, typed OperationDigest/scope, draft/partial/failure outcomes, unknown usage reservations i budżety per scope. |
| P09 | ZAMKNIĘTE | Nowe 08a1–08a3 i 08b1–08b3, integration-only 08a/08b, roadmapa i 09b z 02b; mapa repo/CLI i report/schema/export paths uzupełnione. |

W drugim przebiegu dodatkowo wskazano resztkowe sprzeczności inventory field names, normalized identity, state/value endpoints, Exchange type remap oraz business failure/usage. Autor je zamknął, a reviewer odczytał poprawki. Ostatnie dwa doprecyzowania — wybór analysis mode i foreign keys declarations/cursor parameters/clauses — także odczytano i zatwierdzono. Nie są pozostawione jako zadanie dla wykonawcy do odgadnięcia.

Dalsze ustalanie szczegółów Oracle-version handlers musi odbywać się według udokumentowanych reguł Guide/fixture/gap. Rutynowe decyzje implementacyjne pozostają w etapach i nie zmieniają źródłowych faktów przez LLM.

---

## Historia pierwszego przebiegu — uwagi już zamknięte

Poniższa ocena FAIL dokumentuje problemy wykryte przed poprawkami. Aktualny werdykt pakietu znajduje się na początku raportu i wynosi PASS.


Reviewer: osobny model **gpt-6-astra**, osobny agent. Zakres pierwszego przebiegu: wszystkie **45 plików** zastanego pakietu, w tym 29 stages, trzy kontrakty, osiem dokumentów głównych oraz pięć plików examples (Markdown, JSON i SQL). Raport oceniany osobno przez orkiestratora. Nie wykonano Oracle ani przyszłego parsera.

## Pierwszy werdykt: FAIL dokumentacji

Zidentyfikowano zamknięty katalog konkretnych luk kontraktowych poniżej. Brak real Oracle, DDL i fixtures jest jawnym gate wykonania, **nie blokerem dostarczenia dokumentacji**. Nie wymagamy ustalenia wszystkich reguł Oracle przed etapem, który ma je zweryfikować. Własne formaty programu, kolejność bramek i referencje między DTO muszą natomiast być określone bez domysłów.

Zgodne z intencją: trzy oddzielne projekty A/B/C, dowolna kolejność technologii, zachowanie surowych danych niezależne od kompletności semantyki, obowiązkowy gate definicji, deterministyczny IR oddzielny od BusinessDescriptionIR i brak wykonywania źródeł/dbt w obecnym zakresie.

## Konkretne poprawki i pytania

### P01 — input, identifier i inventory schema

`ObjectKey` nie ma typów owner/name ani formalnego scope schema; tekst wymaga quoted flags. Przykład inventory używa zwykłych stringów, `kind=package` wobec schema kind `package_spec|package_body`, oraz `object_names`, którego InventoryAttestation nie dopuszcza przy extra=forbid. `source_ref` nie określa struktury/odniesienia. Runtime bindings to pattern→jeden obiekt, a dynamic stage wymaga alternatives+conditions.

Wymagane: zdefiniować wejściowy ObjectKey/SchemaScope i mapowanie do normatywnych Identifier, package aggregate scope, inventory envelope/objects/source provenance. Example JSON ma walidować się bez wyjątków od extra=forbid. Oddzielić pisownię i quoted metadata od normalized identity; dwa zapisy tego samego normalizowanego identyfikatora nie mogą tworzyć dwóch różnych obiektów. Formalny manifest/binding schema wraz z exact matching i zamkniętym zbiorem alternatyw. Podawać, jak runtime mode i testowana Oracle version wchodzą do konfiguracji analizy.

### P02 — evidence i źródła

Evidence deklaruje dla config `manifest source_id+pointer`, lecz model nie ma pola config source_id. Derived evidence ma wymagać wersji handlera, lecz brak pola rule_version. `H(raw bytes)` jest sprzeczne z definicją H przyjmującą canonical JSON.

Wymagane: evidence source/config/derived jako pełne pola albo discriminated union, z formalnymi wymaganiami null/nonempty. Config file/manifest musi istnieć jako adresowalne source. Derived parent references i rule version jawne. Source content digest to SHA256(raw bytes), pozostałe H to canonical JSON. Dodać test evidence roundtrip i wskazania właściwych bytes/codepoints w Unicode.

### P03 — domknięcie modeli źródłowego IR i ID

Scope/symbol tables są używane, ale brak modeli Scope/Symbol i formuł ich ID. Branch/loop/cursor/exception/transaction/assignment to głównie proza, bez miejsca w modelu StatementIR przy extra=forbid. Model Parameter nie mieści NOCOPY wymaganego stage 03c. ReadBinding.asset_ref_id odwołuje się do nieistniejącego źródłowego AssetRef, a Exchange powstaje później. Wiele definicji ID (program/block/query/value/write/call/dependency) pozostawiono do domysłu. Program package/spec/body oraz anonymous source wymagają jednoznacznego powiązania, nawet jeśli pewien wariant pozostaje opaque.

Wymagane: normatywne małe DTO dla tych struktur i ich mapy w artifact; wszystkie foreign keys mają typ i kolekcję docelową. Ustalić deterministyczne ID, powiązania program/spec/body/routine/scope, typed parameters oraz source asset references albo zastąpić je references do istniejącego SchemaIR. Opaque modele mogą zachować unsupported semantykę bez udawania COMPLETE.

### P04 — semantyczna kolejność DDL

Manifest file order ma być sortowany po paths, a 04a stosuje CREATE/ALTER w jawnej kolejności. Nie określono, skąd ta kolejność pochodzi między plikami. Kolejność alfabetyczna może odwrócić ALTER i CREATE.

Wymagane: osobne pole `ddl_order`/ordered source units w manifeście, wpływające na analysis ID. Canonical porządek listy plików nie zastępuje kolejności semantycznej. Brak lub sprzeczna sekwencja przy wymagającej kolejności aktualizacji blokuje effective schema, zamiast wybierać dowolny wynik. Golden: dwa pliki o nazwach sortujących się przeciwnie do CREATE→ALTER.

### P05 — preflight dynamic SQL i closure gate

05b wymaga odkrycia wszystkich dependencies przed semantic analyzer, ale 08c dopiero składa literalny dynamic SQL i odkrywa jego tabele. Bez jawnego discovery-only etapu prowadzi to do blokady poprawnego literalnego przypadku lub do uruchomienia semantyki przed gate. Pattern external binding nie opisuje finite alternatives i ich kompletności.

Wymagane: discovery-only hook dla EXECUTE IMMEDIATE/OPEN FOR/DBMS_SQL przed gate, który wyłącznie parsuje źródło/konstrukcję i rozszerza dependency worklist. Literal query ma trafić do normalnego gate przed SqlAnalyzer; nieznana konstrukcja lub nieudowodniona lista runtime obiektów blokuje dependency discovery. Zdefiniować odpowiedzialność 05a/05b/08c, monotoniczny closure/fixed point, inventory attestation warunki oraz test spy Analyzer nieuruchamianego przy brakującej definicji odkrytej w dynamic SQL.

### P06 — wartości, stan i kolejne zapisy

WriteBinding.assignments nie wskazuje output_value_id; ValueOccurrence role variable nie wskazuje symbol_id. Rozróżnienie starych i nowych wartości oraz branch alternatives istnieje tylko opisowo. Dwa różne IDs kolejnych UPDATE nie dowodzą poprawnej zależności między ich stanami. Wspólny physical column nie może zastąpić wartości per statement/branch.

Wymagane: jawne output values, symbol occurrence, state versions/transitions lub równoważny kontrakt. Branch joins wiążą value alternatives z warunkami; loops są iteration-dependent; target reads odnoszą się do właściwego stanu, bez nieudowodnionego połączenia wierszy. Testy: równoczesne `SET a=b,b=a`, kolejne `SET a=1` i `SET b=a`, branch assignment przed odczytem i rollback/exception state. Unknown overlap/context ma inferred/unknown z gap. Zachować te informacje w Exchange.

### P07 — referencje i typy ExchangeIR

Exchange deklaruje, że wszystkie endpoints istnieją, ale ControlEdge zachowuje source statement IDs bez kolekcji statements, ExpressionIR zachowuje reference_id/type_id bez references/types w envelope, a program_ref/context_ref nie mają formalnego typu. DataType projekcja może zawierać nested type IDs bez ich definicji. Call target routine/package nie ma jawnego kind. Source element locators nie zastępują automatycznie lokalnego FK.

Wymagane: jasno rozróżnić local exchange IDs i typed source locators; remapować control endpoints na operations albo dostarczyć odpowiednie kolekcje. Typy i references rematerializować z zamknięciem albo inline descriptor z określoną reprezentacją cykli. Określić call/program/context refs i preserving state. Dodać contract validator sprawdzający każdą kategorię FK, w obu technologicznych kierunkach; minimum consumer pozostaje wyłącznie testem, nie projektem C.

### P08 — finalny BusinessDraft i statusy opisu

BusinessDraft ma summary:str, po czym kontrakt nakazuje summary_segments zamiast uncited summary; local_rule_key nie jest polem BusinessRule-without-ID. OperationDigest i poprzedni/następny kontekst nie mają modeli. Failed/partial budget outcome nie ma jednoznacznego statusu finalnego description. Scope program packet nie wyjaśnia routine_id nullable. Token usage null musi być dopuszczone w typie i nie może pozwolić na nieograniczone calls.

Wymagane: jeden normatywny draft/final schema, osobne DraftRule i accepted BusinessRule z mapą local→final ID, typed summary references i ContextPacket/OperationDigest. Określić status failed/partial/draft/accepted, mandatory gap propagation oraz no-publish reguły po structurally invalid response. Program synthesis używa final rule IDs i pozostawia źródłowy IR bez zmian. Budżety/stopping muszą działać także przy usage unknown, np. przez pre-reserved tokens i twarde calls/output limits.

### P09 — małe etapy, zależności i dozwolone pliki

09b nie wymienia 02b w zależnościach, choć roadmapa wymaga go w prozie. 08a obejmuje naraz state, branches, loops i cursors; 08b calls, exceptions i transactions. Mapa repo pomija wymagane `scripts/export_oracle.sql`, schema input i reports. 09a wymaga CLI analyze, choć CLI nie jest na liście plików. Brak jednego minimalnego kontraktu CLI/input-output/error codes do wdrożenia i instrukcji operacyjnej.

Wymagane: rozdzielić 08a i 08b na małe podetapy w osobnych plikach z kryteriami i końcowym gate integracyjnym; zsynchronizować roadmapę i nagłówki dependency. Uzupełnić architekturę o jawnie wymagane ścieżki oraz minimalne komendy, JSON/report output i exit statuses. Nie dodawać niepotrzebnych nowych produktów ani wdrożenia Oracle.

## Ocena każdego pliku — pierwszy przebieg

PASS lokalny oznacza, że plik ma jasny własny zakres; nie oznacza PASS całego pakietu przy otwartych wspólnych kontraktach.

| Plik | Ocena | Uwaga |
|---|---|---|
| `README.md` | PASS lokalny | Jasne trzy projekty i brak automatycznej zgodności PowerCenter. |
| `00-CONTEXT.md` | PASS lokalny | Pełność zachowania oddzielona od semantyki, obowiązkowy gate. |
| `01-ARCHITECTURE.md` | FAIL | P03/P09: brakujące modele/artefakty i ownership nowych plików. |
| `02-EXECUTION.md` | PASS lokalny | Runtime status oddzielony od stage outcome, strict gate jawny. |
| `03-ORACLE-INPUT.md` | FAIL | P01/P04/P05: inventory/bindings/order wymagają formalnego schematu. |
| `04-ROADMAP.md` | FAIL | P09: 09b dependency 02b i podział 08a/08b. |
| `05-TESTS.md` | PASS lokalny | Niezależny golden, conservative completeness i real gate. Dodać testy z poprawek. |
| `06-SOURCES.md` | PASS lokalny | Zakres weryfikacji i wersja Oracle nie są zawyżone. |
| `contracts/IR.md` | FAIL | P01–P06: niepełne struktury/ID, evidence, state i gate contract. |
| `contracts/EXCHANGE.md` | FAIL | P07: niedomknięte FK/type/control references. |
| `contracts/BUSINESS.md` | FAIL | P08: sprzeczny draft i niepełne typed packet/statusy. |
| `examples/README.md` | PASS lokalny | Sample i expected logic jawnie syntetyczne, typ wyniku nie utożsamiony z target. |
| `examples/customer_pkg.sql` | PASS lokalny | Mały sample INSERT SELECT spójny z opisem. Nie wykonywano go w Oracle. |
| `examples/schema.sql` | PASS lokalny | Pasujące source/target/default nullability i PK. |
| `examples/input-manifest.json` | FAIL | P01/P04: dopasować do finalnego normatywnego manifestu i kolejności DDL. |
| `examples/inventory.json` | FAIL | P01: object_names/scope/kind/Identifier niezgodne z pierwotnym DTO. |
| `stages/01.md` | FAIL | P03/P07/P08: nie da się wygenerować jednoznacznych schem z niepełnych DTO. |
| `stages/02a.md` | FAIL | P01: formalne inventory/synthetic profile wymagają doprecyzowania. |
| `stages/02b.md` | FAIL | P01/P09: final input schema oraz export path ownership. |
| `stages/03a.md` | PASS lokalny | Reader/ZIP/Unicode/source spans mają sprawdzalne kryteria. |
| `stages/03b.md` | PASS lokalny | Prawdziwy ANTLR, pinning i recovery nie udają complete. |
| `stages/03c.md` | FAIL | P03: scope/symbol/parameter/program structures niedomknięte. |
| `stages/04a.md` | FAIL | P04: brak źródła kolejności CREATE/ALTER między plikami. |
| `stages/04b.md` | FAIL | P01/P03: inventory i rodzaje object/refs muszą być wspólne. |
| `stages/05a.md` | FAIL | P03/P05: discovery-only dynamic closure i typed scope. |
| `stages/05b.md` | FAIL | P05: spy analyzer gate wymaga wcześniejszego dynamic discovery. |
| `stages/06a.md` | PASS lokalny | Strukturalna extraction, raw mapping i unsupported fallback jawne. |
| `stages/06b.md` | PASS lokalny | Oracle rule evidence/unknown type bez zgadywania. |
| `stages/06c.md` | PASS lokalny | Mandatory subset i value/filter/join/group/rowset kryteria rozdzielone. |
| `stages/07a.md` | FAIL | P06: binding nie wskazuje output value, potrzebny pełny typed mapping. |
| `stages/07b.md` | FAIL | P06: old/new i sequential state wymagają modelu i testu zależności. |
| `stages/07c.md` | PASS lokalny | DELETE/TRUNCATE i effects jawnie rozróżnione. |
| `stages/07d.md` | FAIL | P03/P06: typed branch/order/row-state kontrakt musi istnieć. |
| `stages/08a.md` | FAIL | P03/P06/P09: duży zakres i nieokreślony model state/control/cursor. |
| `stages/08b.md` | FAIL | P03/P06/P09: calls/exceptions/transactions wymagają mniejszych stages i modeli. |
| `stages/08c.md` | FAIL | P05: odkrycie tabel w literalnym SQL musi poprzedzać semantyczny gate. |
| `stages/09a.md` | FAIL | P02/P03/P09: FK/evidence walidacja i CLI/report ownership niepełne. |
| `stages/09b.md` | FAIL | P09: brak wymaganej 02b w nagłówku zależności. |
| `stages/10a.md` | FAIL | P07: validator foreign keys nie ma zamkniętych collections. |
| `stages/10b.md` | FAIL | P07: minimal consumer potrzebuje jawnego local/source reference mapping. |
| `stages/11a.md` | FAIL | P08: brak normatywnego OperationDigest i ContextPacket typing. |
| `stages/11b.md` | FAIL | P08: sprzeczne schema draft/final i failure status. |
| `stages/11c.md` | FAIL | P08: remapowanie accepted rule IDs i status publikacji musi być jednoznaczne. |
| `stages/11d.md` | PASS lokalny | Human review i ograniczenie claims przy code status=3 jasne. |
| `stages/12.md` | PASS lokalny | Zakres przyszłego TestSpec/execution rozdzielony od obecnego odbioru. |

## Ponowny review

Autor poprawia wyłącznie dokumentację. Reviewer odczytuje wszystkie zmienione i nowo utworzone pliki oraz zamyka P01–P09 dowodem w poprawionym tekście. Werdykt końcowy będzie dotyczył dokumentacji, nie pracy przyszłego parsera ani Oracle execution equivalence. Rutynowe wybory implementacyjne i zadeklarowane Oracle-version gates nie są samodzielnym powodem FAIL.
