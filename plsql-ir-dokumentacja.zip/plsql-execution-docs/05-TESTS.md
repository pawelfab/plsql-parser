# Strategia testów i macierz obowiązkowa
## Poziomy
Unit: source offsets, scope/name resolution, handlers types/query/DML/control. Integration: code+DDL→gate→IR→roundtrip. Contract: source IR→ExchangeIR→minimal consumer. Acceptance: ręcznie potwierdzone real corpus i opis biznesowy. Brak wykonania Oracle/dbt nie blokuje poprawności parsera; nie oznacza execution equivalence.

## Golden oracle
Expected inventory/IR fragment autor testu przygotowuje ręcznie z kodu i dokumentacji; parser nie generuje własnych expected fixtures. Ewentualna aktualizacja golden wymaga review różnicy semantycznej, nie snapshot auto-accept. Fixture examples syntetyczna, nie reprezentuje pełnego Oracle.

| Rodzina | Obowiązkowe przypadki | Dowód odbioru |
|---|---|---|
| Reader | Unicode/CRLF/q quotes/semicolon comments/ZIP escape | Exact raw+span+coverage |
| DDL | char semantics/defaults/virtual/constraints/ALTER/types/view/synonym | Type fields+dependencies+evidence |
| Gate | missing table/type/callee/trigger inventory/opaque refs | Blocks semantic invocation, full missing report |
| SELECT | aliases/CTE/*/outer join/aggregate/count/union | Value vs filter/join/rowset, ordered projections |
| Writes | insert ordinal/default, simultaneous update, delete, merge branches | Target bindings and old/new value occurrences |
| PL/SQL | scope overloads/cursor/if/loop/call/exception/transactions | Ordered blocks+control+effects |
| Dynamic | literal query, runtime object unresolved, binds | Derived evidence or blocked discovery |
| Conservation | unknown Oracle construct/comments/hints | 100% raw+syntax conservation, opaque visible |
| Exchange | technology-only and both orders, duplicate db names | No false identity/paths, gaps preserved |
| Business | unsupported facts/ambiguity/status code meaning/injection | Reject fabrications, cite valid scope, budgets |
| Artifact | failure/retry/conflict/unknown schema/immutable revisions | No partial publish, deterministic hashes |

## Minimalne real acceptance
Source: minimum 3 routines/packages i 10 expression/type oraz 10 write/source checks. Business: 3 routines, w tym częściowo rozpoznany program. Operator zna Oracle semantics i potwierdza expectations. Nie udawaj real execution; jeśli korzystamy tylko z syntetycznych fixtures status PASS_SYNTHETIC. Strict gate missing defs zawsze blokuje, nawet synthetic.

## Przyszła walidacja wykonania
Osobny executor źródła i dbt celu dostaje identyczne wejścia+stan target+parameters/time/NLS. Compare map columns/PK/null/tolerances/multisets, preserve side effects and transactions as scoped. TestSpec wskazuje coverage warunków, constraints i nondeterminism. Przejście testów to zgodność sprawdzonych przypadków, nie matematyczny dowód pełnej równoważności. Ten pakiet tylko zapewnia potrzebne pola IR i dokumentuje boundary.

## Dodatkowe testy kontraktowe
Normalized unquoted names same object; quoted lowercase distinct. Identifier original text zachowany ale nie duplikuje physical key. Evidence config file addressing+derived handler version. CREATE/ALTER opposite filenames explicit ddl_order. Literal dynamic missing object gate before analyze. Sequential conditional writes with unknown row overlap inferred, branch/state/rollback completeness. Exchange ref/type/control closure and draft local_rule_key→rule_id remapping; unknown token usage conservative limits.
