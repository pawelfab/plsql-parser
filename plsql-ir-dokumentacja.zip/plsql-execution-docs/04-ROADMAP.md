# Etapy i punkty odbioru

- [01 — Szkielet i kontrakty modeli](stages/01.md); zależności: brak.
- [02a — Profil Oracle i inventory wejścia](stages/02a.md); zależności: 01.
- [02b — Eksport definicji Oracle](stages/02b.md); zależności: 02a.
- [03a — Reader i lossless source archive](stages/03a.md); zależności: 02a.
- [03b — ANTLR build i parser syntax](stages/03b.md); zależności: 03a.
- [03c — Pełny syntax inventory i struktura programu](stages/03c.md); zależności: 03b.
- [04a — DDL tabel i column types](stages/04a.md); zależności: 03c.
- [04b — Widoki, synonimy, typy i obiekty zależne](stages/04b.md); zależności: 04a.
- [05a — Scopes, symbole i discovery zależności](stages/05a.md); zależności: 04b.
- [05b — Obowiązkowy gate definicji](stages/05b.md); zależności: 05a.
- [06a — Adapter SQL i wiązanie kontekstu PL/SQL](stages/06a.md); zależności: 05b.
- [06b — Wyrażenia i typowanie Oracle](stages/06b.md); zależności: 06a.
- [06c — SELECT query tree i dependencies](stages/06c.md); zależności: 06b.
- [07a — INSERT i przypisanie target columns](stages/07a.md); zależności: 06c.
- [07b — UPDATE](stages/07b.md); zależności: 07a.
- [07c — DELETE i TRUNCATE](stages/07c.md); zależności: 07b.
- [07d — MERGE](stages/07d.md); zależności: 07c.
- [08a1 — Control flow i rozgałęzienia](stages/08a1.md); zależności: 07d.
- [08a2 — Stan wartości i kolejne zapisy](stages/08a2.md); zależności: 08a1.
- [08a3 — Pętle, cursory i bulk constructs](stages/08a3.md); zależności: 08a2.
- [08a — Integracja control/state/cursors](stages/08a.md); zależności: 08a3.
- [08b1 — Wywołania i package initialization](stages/08b1.md); zależności: 08a.
- [08b2 — Wyjątki](stages/08b2.md); zależności: 08b1.
- [08b3 — Transakcje i efekty uboczne](stages/08b3.md); zależności: 08b2.
- [08b — Integracja calls/exceptions/transactions](stages/08b.md); zależności: 08b3.
- [08c — Dynamiczny SQL i zależności kontekstowe](stages/08c.md); zależności: 08b.
- [09a — Zapis artefaktów i kompletność](stages/09a.md); zależności: 08c.
- [09b — Odbiór źródłowego IR](stages/09b.md); zależności: 09a i 02b.
- [10a — Eksport ExchangeIR](stages/10a.md); zależności: 09b.
- [10b — Zgodność A/B bez narzuconej kolejności](stages/10b.md); zależności: 10a.
- [11a — Builder kontekstu biznesowego](stages/11a.md); zależności: 10b.
- [11b — Typowany agent LLM i walidacja dowodów](stages/11b.md); zależności: 11a.
- [11c — Składanie i publikacja opisu programu](stages/11c.md); zależności: 11b.
- [11d — Odbiór opisu biznesowego](stages/11d.md); zależności: 11c.
- [12 — TestSpec-ready kontrakt i operacyjny odbiór](stages/12.md); zależności: 11d.

## Kiedy wynik jest użyteczny
03c: source inventory i lossless archive, jeszcze nie rozpoznana pełna logika. 05b: kompletność definicji lub precyzyjny blocked report. 06c/07a: pierwsza pionowa ścieżka SELECT/INSERT → semantyczny IR (provisional demo przed pełnym artifact publish 09a). 09b: odebrany źródłowy IR. 10b: kontraktowa zgodność do przyszłego C, real PowerCenter adapter nadal osobny gate. 11d: odebrany biznesowy opis jednej technologii. 12: operacyjny odbiór i dane przygotowane pod późniejsze TestSpec/dbt.

Dwa tory po 02a: 02b eksport i 03a reader mogą być rozwijane niezależnie. 09b wymaga 02b PASS oraz real fixtures; syntetyczny kod działa wcześniej. Nadrzędne source/data gates nie mogą być pominięte przez roadmapę.
