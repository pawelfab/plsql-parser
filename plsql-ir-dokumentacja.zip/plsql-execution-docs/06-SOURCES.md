# Źródła i status weryfikacji
Data odnalezienia oficjalnych adresów i fragmentów: 2026-10-07. Nie zweryfikowano pełnej gramatyki na danych użytkownika ani kompletnej semantyki Oracle. Rzeczywista wersja Oracle nie została podana; doc links 19c są punktem odniesienia, nie deklaracją zgodności produktu.
- Oracle DBMS_METADATA 19c: https://docs.oracle.com/en/database/oracle/oracle-database/19/arpls/DBMS_METADATA.html — GET_DDL i funkcje dependent metadata.
- Oracle PL/SQL Language Reference 19c: https://docs.oracle.com/en/database/oracle/oracle-database/19/lnpls/index.html — normatywna semantyka języka po sprawdzeniu właściwej wersji.
- Oracle SQL Language Reference 19c: https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/index.html — SQL/types/expressions.
- ANTLR grammar: https://github.com/antlr/grammars-v4/tree/master/sql/plsql ; PlSqlLexer.g4/PlSqlParser.g4 i Python3 base classes. To community grammar, nie oficjalny Oracle parser.
- SQLGlot: https://sqlglot.com/sqlglot/ ; Oracle dialect: https://sqlglot.com/sqlglot/dialects/oracle.html ; qualification: https://github.com/tobymao/sqlglot/blob/main/sqlglot/optimizer/qualify.py . AST może normalizować kod, dlatego raw input jest przechowywane oddzielnie.
- Pydantic docs: https://docs.pydantic.dev/latest/ ; Pydantic-AI: https://ai.pydantic.dev/ . Stage 01/11a ustala przypięte kompatybilne wersje z oficjalnych docs.

Wykonawca zapisuje exact grammar commit SHA, ANTLR tool/runtime match, SQLGlot version, Oracle tested versions i licence files. Żadnego "latest" w lockfile. Każda implemented semantic rule ma Guide section+fixture, nie tylko ten ogólny wykaz źródeł.
