CREATE OR REPLACE PACKAGE DWH.CUSTOMER_PKG AS
  PROCEDURE load_customers(p_run_date IN DATE);
END CUSTOMER_PKG;
/
CREATE OR REPLACE PACKAGE BODY DWH.CUSTOMER_PKG AS
  PROCEDURE load_customers(p_run_date IN DATE) IS
  BEGIN
    -- Synthetic example: copy active customers and compute amount.
    INSERT INTO DWH.CUSTOMER_OUTPUT (customer_id, amount, run_date)
    SELECT s.customer_id, NVL(s.price, 0) * s.quantity, p_run_date
    FROM DWH.CUSTOMER_INPUT s
    WHERE s.active = 'Y';
  END load_customers;
END CUSTOMER_PKG;
/
