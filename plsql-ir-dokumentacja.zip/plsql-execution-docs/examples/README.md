# Przykład syntetyczny — wejście, nie gotowy IR
Pliki pokazują format dostawy Oracle. To tekstowe sample do implementacji golden tests, nie dowód działania parsera. Baseline przykład Oracle 19c; rzeczywisty projekt dobiera użytkownik version. Nie uruchamiaj kodu jako część parsera.

- [Kod](customer_pkg.sql): spec+body procedury load_customers(p_run_date DATE).
- [Definicje](schema.sql): input/output tables i PK.
- [Manifest](input-manifest.json): pełny kontekst wejścia.
- [Inventory](inventory.json): syntetyczne potwierdzenie kompletności dependencies/triggers.

## Ręcznie określone oczekiwania
Source CUSTOMER_INPUT, target CUSTOMER_OUTPUT. Procedure INSERT SELECT. customer_id przepisany bez zmiany, amount=NVL(price,0)*quantity, run_date=parameter p_run_date. WHERE active='Y' wpływa na wybór rowset, nie value amount. Input price NUMBER(12,2), quantity NUMBER(10,0), target amount NUMBER(24,2); expression result type wyznacza własna reguła Oracle, nie utożsamiać automatycznie z target type. Target PK customer_id: constraints zachowane, możliwy duplicate-key exception nie ukryty. Ten przykład nie ma IF/MERGE/calls/triggers/dynamic SQL. Brak zewnętrznych call definitions dotyczy wyłącznie NVL z builtin registry.

## Negatywne warianty testów
Usuń schema.sql→missing definitions; usuń trigger attestation→incomplete inventory; zmień owner→missing object; dodaj drugi source o tej samej nazwie w innym owner→no accidental merge; nazwij komentarz instrukcją dla LLM→no execution/no extra read. Examples nie zawierają generowanego expected pełnego IR: stage autor przygotowuje go niezależnie według kontraktu.
