# Wejście Oracle i eksport bez dodatkowej konwersji
## Format podstawowy
Natywne Oracle DDL i kod PL/SQL w .sql/.pks/.pkb; katalog lub ZIP z tymi plikami i manifestem JSON. Manifest to kontekst eksportu, nie konwersja definicji. DDL z DBMS_METADATA jest przyjmowany bez własnego JSON opisu tabel. Plik .dmp nie jest obsługiwany; jeśli operator ma Data Pump, generuje SQLFILE osobno. Nie zakładamy, że GET_DDL jednego pakietu zbierze wszystkie zależności.

## Manifest v1
input_schema_version=1, analysis_mode:synthetic|real, oracle_version (dokładna wersja), database_key (niesekretny identyfikator instancji), environment, default_schema, edition|null, nls_parameters dict str→str, timezone|null, files list[{path,role:code|definition|context,encoding,sha256|null}], entrypoints list[{owner,package|null,routine}], ddl_order:list[path], dynamic_bindings:list[DynamicBinding], external_bindings list[{reference_pattern,object:{database_key,owner,name,kind}}]. SHA opcjonalny przy wejściu, reader zawsze oblicza. Brak edition/timezone oznacza unknown context i wpływający gap gdy używane, nie dowolny default. nls_parameters: eksport rzeczywistych wartości istotnych dla kodu (NLS_DATE_FORMAT, NLS_NUMERIC_CHARACTERS, NLS_SORT/NLS_COMP); {} jawnie unknown. Preferowany UTF-8, inne kodowania deklarowane; parser nie autodetekuje bez jawnego wyniku.

## Definicje obowiązkowe według zależności
Package spec+body, odwoływane tabele i kolumny, widoki+ich dependencies, synonyms+targets, user-defined types spec/body, routine signatures/bodies dla analizowanych calls, sequences/triggers/constraints/defaults/virtual columns wpływające na analizowane writes. Indeksy i storage clauses zachowaj jeśli dostarczone; nie są automatycznie warunkiem rozpoznania value semantics. Obiekt będący table target wymaga także katalogu aktywnych triggerów: pusty trigger inventory to jawne potwierdzenie eksportu, nie wniosek z braku plików.
Definicje built-ins Oracle nie są wymagane w plikach: wersjonowany builtin_registry identyfikuje jawnie wspierane system functions/packages i ich signatures/semantics. Nieznany SYS object nie dostaje zwolnienia tylko z powodu właściciela SYS. Wrapped PL/SQL wymaga jawnej informacji o braku dostępnego body i daje blocked dependency discovery lub partial call semantics zgodnie z kontraktem.

## Procedura eksportu operatora
1. Wybierz entrypoints i real Oracle version/environment.
2. Eksportuj spec/body i definicje przez DBMS_METADATA.GET_DDL z names/owner w oryginalnej pisowni; metadane zależne pobierz jawnie GET_DEPENDENT_DDL lub inventory views.
3. Zbierz dependency inventory z ALL_DEPENDENCIES (lub DBA_DEPENDENCIES przy odpowiednich uprawnieniach) jako pomoc. To nie wystarcza do runtime dynamic SQL; brak dostępu nie oznacza brak zależności.
4. Eksportuj strukturę oraz wpływające triggery/constraints i definicje zależne rekurencyjnie. Operator dostarcza inventory completeness attestations, zobacz IR contract.
5. SPOOL bez headings/pagination/wrapping/truncation CLOB; jawnie ustaw encoding i terminatory. Natywne delimitery ; i / przyjmie sql_script adapter. SQL*Plus SET/SPOOL/PROMPT zachowane jako source directives, nie executed.
6. Parser preflight zwraca ewentualne brakujące definicje; operator uzupełnia eksport i ponawia import. Żadnego automatycznego pobierania w runtime.

## Minimalny przykład odczytu definicji
```sql
SELECT DBMS_METADATA.GET_DDL('TABLE', 'CUSTOMER', 'DWH') FROM dual;
```
To przykład pobrania jednego obiektu, nie pełny skrypt eksportowy. Dokładny export tool stage 02b uwzględnia wersję Oracle i kompletność inventory. Nigdy nie usuwa constraints/defaults/char semantics tylko dla krótszego output.

## Ochrona wejścia
ZIP: brak absolute paths, .., symlinks i duplicate normalized paths. Limity 100 MiB/pliku, 1 GiB uncompressed bundle, 10 000 plików; przekroczenie invalid input lub jawna konfiguracja operatora. @/@@ SQL*Plus includes nie są wykonywane; jawna obecność pliku w manifest pozwala readerowi rozwiązać lokalną referencję bez path escape. Brak included file=missing definition/input. Database links wymagają bindings i definicji remote objects w pakiecie.

## Kolejność DDL i bindings — część manifestu v1
`ddl_order` to lista paths role=definition w kolejności odtworzenia CREATE/ALTER. Każdy definition file dokładnie raz; kolejność statements wewnątrz pliku oryginalna. Brak ddl_order dla jednego pliku: reader wstawia jedyny path; dla wielu plików bez ddl_order INVALID_INPUT. Code file order nie implikuje execution schedule.
DynamicBinding={binding_id:str,source_path:str,statement_start_line:int,kind:sql_text|object_name,exhaustive:bool,variants:list[{value:str,condition_label:str|null}]}. Dynamic_binding selektor dokładny source path+start line, nie fuzzy routine match. sql_text wariant zawiera cały możliwy SQL; object_name tylko wartość identyfikatora i builder musi być rozpoznany aby ją osadzić w odpowiednim miejscu. exhaustive=true to jawne zaświadczenie operatora z config evidence; false lub brak dla nieznanej nazwy blokuje discovery. Wszystkie variants parsowane, defs closure po union. Runtime wybrany wariant nie jest faktem, certainty inferred i condition_label nie udaje analizowanego warunku kodu. Semantics complete=false gdy brak dowodu exhaustive wariantów z samego kodu; gate może przejść dzięki dostarczonemu inventory i deklaracji operatora.
External_binding.reference_pattern to dokładna nazwa referencji (w tym db link) do dopasowania, nie regex ani wildcard; multiple match conflict. Target object ma database_key,owner,name,kind; environment bierze manifest, remote environment inne wymaga jawnego pola target_environment. Definicje remote dostarczone z owner/key mapping, nie czytane z sieci.

analysis_mode jest wymaganym polem manifestu; CLI go nie zgaduje po nazwie environment/version. Brak=INVALID_INPUT. Wchodzi w semantic context hash i analysis_id. Real mode musi mieć dokładną wersję Oracle; synthetic mode to jawny profil fixtures.
