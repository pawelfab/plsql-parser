# Kontekst, cel i granice
## Uzgodniony podział
Projekt A analizuje wyłącznie PowerCenter XML i ma własny pełny IR. Projekt B (ten pakiet) analizuje PL/SQL razem z dostarczonymi definicjami Oracle i ma własny pełny IR. Projekt C importuje wyniki A/B, uzgadnia tożsamość obiektów i tworzy globalne grafy oraz narzędzia dla LLM. Technologie mogą występować w dowolnej kolejności; przepływ może korzystać tylko z jednej. Nie zakładamy PowerCenter→PL/SQL ani wspólnego harmonogramu.

## Cel projektu B
Deterministycznie zachować kod, strukturę programu i metadane; rozpoznać logikę instrukcji, wyrażenia, typy, odczyty/zapisy, control flow, wywołania i skutki uboczne. Wynik czytelny dla programów i LLM, bez zależności od AST bibliotek. Równolegle umożliwić warstwę opisu biznesowego LLM, która nie zmienia faktów IR. Rozszerzenie do migracji dbt i walidacji wykonania jest osobnym późniejszym zakresem: obecny IR zachowuje potrzebną semantykę, ale ten plan nie implementuje generatora dbt ani wykonania Oracle/PowerCenter.

## Pełność ma dwa znaczenia
Zachowanie: 100% wejściowych bytes plus lossless source/token ranges i inventory constructs; nieznane zachowania mają opaque nodes i raw references. Semantyka: wyłącznie elementy obsługiwane i zweryfikowane mają recognized status. Nie wolno obiecać pełnej interpretacji całego Oracle w MVP. Celem architektury jest pełny model i rozszerzalne handlers; pierwszy release ma jawną macierz obsługi i zero silent drops.

## Warunek obowiązkowych definicji
Tabele, widoki, typy, synonimy, wywoływane obiekty i inne potrzebne definicje użytkownik dostarcza wraz z pakietem jako Oracle DDL SQL. Brak wymaganej definicji zatrzymuje analizę semantyczną i zwraca listę braków z odwołaniami. Preflight może sparsować składnię, aby znaleźć zależności, ale nie publikuje wtedy finalnego semantycznego IR ani opisu jako gotowego. Nie pobieramy braków z Oracle automatycznie i nie odtwarzamy ich przez LLM.

## Zakres wyjścia
SchemaIR, PackageIR, SqlStatementIR, ExpressionIR, control/call/type information, manifest wejść, completeness report, evidence, diagnostics, unresolved; osobno ExchangeIR oraz BusinessDescriptionIR. Wszystkie source/target to role obiektów w konkretnej operacji. Nie globalny typ tabeli.

## Zakres poza programem
Global graph repository/Neo4j, międzytechnologiczna identity reconciliation, globalne upstream/downstream, dbt generator, produkcyjne wykonywanie źródeł/celów, harmonogramowanie i GUI. Lokalny dependency view w IR jest faktem analizy, nie projektem C. Business module opisuje pojedyncze routines/programs; opis całej hurtowni powstaje w C.

## Stack
Python 3.12; ANTLR4 z przypiętym grammars-v4 i Python runtime, SQLGlot Oracle przez adapter, Pydantic v2, pydantic-settings, Typer, pytest. Pydantic-AI dopiero business stage. ANTLR generation wymaga Java zgodnej z przypiętą wersją narzędzia w build; runtime parsera nie wymaga Java. SQLGlot nie jest pełnym interpreterem Oracle; brak rozpoznania nie uruchamia regex fallback jako EXACT. Modele neutralne i wersjonowane, JSON UTF-8, raw archiwum.
